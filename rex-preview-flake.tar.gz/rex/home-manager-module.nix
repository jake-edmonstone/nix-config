self: {
  config,
  lib,
  pkgs,
  ...
}: let
  cfg = config.programs.rex;
  serverCfg = config.services.rex;

  # Both Rex flakes export this module, so `package` defaults to the Rex that
  # came with it, built for the machine being configured.
  defaultPackage =
    self.packages.${pkgs.stdenv.hostPlatform.system}.rex
    or self.packages.${pkgs.system}.rex;

  # The Rex package ships its terminfo entry and its ssh guard at these paths.
  # nix/package.nix installs them, and so does the prebuilt flake.
  #
  # These paths exist only when cfg.package is set. Without a package, the
  # terminfo and sshGuard options default to false, and an assertion stops
  # anyone who turns them on anyway, so nothing reads these paths.
  terminfoEntry = "${cfg.package}/share/terminfo/x/xterm-rex";
  terminfoAlias = "${cfg.package}/share/terminfo/r/rex";
  sshGuardFile = "${cfg.package}/share/rex/ssh_config.d/50-rex.conf";

  # The guard that `rex terminfo setup` writes for this account, which lists
  # the hosts the account records. The packaged guard looks for it at exactly
  # this path, and Rex recognizes its own Include line only by the absolute
  # path, so it is built from the home directory rather than from
  # xdg.configHome or a tilde.
  accountGuardFile = "${config.home.homeDirectory}/.config/rex/ssh_config";

  # TERMINFO_DIRS for the service. The server uses xterm-rex only if it can
  # find the entry, and the programs it starts need to find it too. A user
  # service doesn't see home-manager's session variables, so the module names
  # the package's directory itself, which also works with terminfo = false.
  #
  # The trailing colon is deliberate. An empty element means "then the usual
  # places" to ncurses and to Rex, which keeps entries such as xterm-256color
  # working. nix/nixos-module.nix explains this in more detail.
  terminfoDirs = "${serverCfg.package}/share/terminfo:";

  # Flags that extraArgs may not set. A flag that an option also sets would
  # leave the server running with a value the option doesn't show.
  #
  # --listen and --state-dir have no option, but they are refused too. The
  # service leaves them out so the server uses the same socket and state
  # directory as every rex command for this account. Setting either would
  # hide the server from `rex server status` and `rex server stop`.
  managedServeFlags = [
    "--listen"
    "--state-dir"
    "--allow-anonymous"
    "--extra-listen"
    "--websocket-origin-pattern"
    "--block-dir"
    "--block-plugin-reload"
    "--log-format"
    "--max-sessions"
    "--max-blocks"
    "--max-windows"
    "--max-panes"
    "--tailscale"
    "--tailscale-hostname"
    "--tailscale-control-url"
    "--tailscale-allow-tailnet-members"
    "--tailscale-auth-key-file"
    "--tailscale-advertise-tag"
  ];
  isManagedServeArg = arg:
    lib.any (flag: arg == flag || lib.hasPrefix "${flag}=" arg) managedServeFlags;
  managedExtraArgs = lib.filter isManagedServeArg serverCfg.extraArgs;

  # The auth key reaches the server as a systemd credential, as in the NixOS
  # module. LoadCredential copies the file into a directory only the service
  # can read, and %d in ExecStart expands to that directory. User services
  # support LoadCredential from systemd 250.
  tailscaleAuthKeyCredential = "tailscale-auth-key";

  # `rex server run` refuses tags without --tailscale. An assertion already
  # requires tailscale.enable for tags, and this keeps the command consistent
  # with that option on its own.
  tailscaleAdvertiseTagArgs =
    lib.optionals serverCfg.tailscale.enable
    (lib.concatMap (tag: ["--tailscale-advertise-tag" tag]) serverCfg.tailscale.advertiseTags);

  # Only TCP and http:// addresses need allowAnonymous. A Unix socket knows
  # the caller's user ID, and a tailnet address asks Tailscale who is calling.
  isUnixEndpoint = endpoint: lib.hasPrefix "/" endpoint || lib.hasPrefix "unix://" endpoint;
  isTailnetEndpoint = endpoint:
    lib.hasPrefix "tailnet://" (lib.toLower endpoint)
    || lib.hasPrefix "tailnet-serve://" (lib.toLower endpoint);
  hasTcpListener =
    lib.any (endpoint: !isUnixEndpoint endpoint && !isTailnetEndpoint endpoint)
    serverCfg.extraListen;

  # Each variable becomes one quoted Environment= assignment. Without quotes,
  # systemd would split a value at its spaces. systemd also expands % in this
  # setting, so a literal % is doubled.
  environmentAssignment = name: value: let
    escaped = lib.replaceStrings ["\\" "\"" "%"] ["\\\\" "\\\"" "%%"] "${name}=${value}";
  in "\"${escaped}\"";

  serverEnvironment =
    {
      TERMINFO_DIRS = terminfoDirs;
      # GODEBUG adjusts the Go runtime Rex is built with. Go refuses to start
      # if GODEBUG asks for a behavior it has since removed, and some systems
      # set such a value for every session. The user manager would pass it on,
      # so the service clears it. `environment` can still set it on purpose.
      # packaging/systemd/rex.service shows the error this prevents.
      GODEBUG = "";
      # Tells the server that the unit below sets Delegate, so the server may
      # give each terminal a cgroup of its own. Never set it without Delegate.
      # internal/install/units/rex.service explains why.
      REX_CGROUP_DELEGATED = "1";
    }
    // serverCfg.environment;

  execStart = lib.escapeShellArgs (
    [
      (lib.getExe serverCfg.package)
      "server"
      "run"
    ]
    ++ lib.optional serverCfg.allowAnonymous "--allow-anonymous"
    ++ lib.concatMap (endpoint: ["--extra-listen" endpoint]) serverCfg.extraListen
    ++ lib.concatMap (pattern: ["--websocket-origin-pattern" pattern])
    serverCfg.webSocketOriginPatterns
    ++ lib.concatMap (dir: ["--block-dir" dir]) serverCfg.blockDirs
    ++ lib.optional serverCfg.reloadBlockPlugins "--block-plugin-reload"
    ++ [
      "--log-format"
      serverCfg.logFormat
    ]
    ++ lib.optionals (serverCfg.maxSessions != null) ["--max-sessions" (toString serverCfg.maxSessions)]
    ++ lib.optionals (serverCfg.maxBlocks != null) ["--max-blocks" (toString serverCfg.maxBlocks)]
    ++ lib.optionals (serverCfg.maxWindows != null) ["--max-windows" (toString serverCfg.maxWindows)]
    ++ lib.optionals (serverCfg.maxPanes != null) ["--max-panes" (toString serverCfg.maxPanes)]
    ++ lib.optionals serverCfg.tailscale.enable [
      "--tailscale"
      "--tailscale-hostname"
      serverCfg.tailscale.hostname
    ]
    ++ lib.optionals (serverCfg.tailscale.controlUrl != null) [
      "--tailscale-control-url"
      serverCfg.tailscale.controlUrl
    ]
    ++ lib.optional serverCfg.tailscale.allowTailnetMembers "--tailscale-allow-tailnet-members"
    ++ lib.optionals (serverCfg.tailscale.authKeyFile != null) [
      "--tailscale-auth-key-file"
      "%d/${tailscaleAuthKeyCredential}"
    ]
    ++ tailscaleAdvertiseTagArgs
    ++ serverCfg.extraArgs
  );

  # The four limits share one shape. Null leaves the flag out, so the server
  # keeps whatever default the running Rex version has, instead of the module
  # pinning today's number.
  limitOption = {
    what,
    scope,
    rexDefault,
  }:
    lib.mkOption {
      type = lib.types.nullOr lib.types.ints.unsigned;
      default = null;
      example = 16;
      description = ''
        The most ${what} ${scope}. Once the limit is reached, the server refuses
        to create more until some are closed. `0` removes the limit.

        Null, the default, uses Rex's built-in limit, which is currently
        ${toString rexDefault}.
      '';
    };
in {
  options.programs.rex = {
    enable = lib.mkEnableOption "Rex, the terminal multiplexer";

    package = lib.mkOption {
      type = lib.types.nullOr lib.types.package;
      default = defaultPackage;
      defaultText =
        lib.literalExpression
        "rex.packages.\${pkgs.stdenv.hostPlatform.system}.rex";
      description = ''
        The Rex package to install. By default this is the `rex` package from
        the flake you imported the module from.

        Set this to null if `rex` is already installed another way, such as
        with the Rex app on macOS. The module then installs nothing, but still
        writes your configuration:

        ```nix
        programs.rex = {
          enable = true;
          package = null;
          config = ./rex/init.lua;
        };
        ```

        The terminfo entry and the ssh guard come from this package, so
        `terminfo` and `sshGuard` default to false when it is null. Run
        `rex terminfo setup` to install both instead.

        `services.rex` runs this same package unless you set
        `services.rex.package`.
      '';
    };

    terminfo = lib.mkOption {
      type = lib.types.bool;
      default = cfg.package != null;
      defaultText = lib.literalExpression "config.programs.rex.package != null";
      description = ''
        Whether to install Rex's terminal description, `xterm-rex`, in
        `~/.terminfo`.

        Programs such as vim, less, and htop look up the terminal they run in
        to learn what it can do, and some refuse to start if they can't find
        it. A Rex terminal uses `xterm-rex` only when this entry is installed,
        and falls back to `xterm-256color` otherwise.

        The entry and its short name, `rex`, are each written twice, once in
        the layout Linux uses and once in the layout macOS uses, so a home
        directory shared between the two works on both. Running
        `rex terminfo setup` as well is harmless, because it leaves identical
        files alone.

        The files come from `package`. When `package` is null, this option is
        false by default, and setting it to true is an error.
      '';
    };

    sshGuard = lib.mkOption {
      type = lib.types.bool;
      default = cfg.package != null;
      defaultText = lib.literalExpression "config.programs.rex.package != null";
      description = ''
        Whether to add Rex's ssh guard to your ssh configuration.

        When you run `ssh` inside a Rex terminal, ssh passes `TERM=xterm-rex`
        to the remote machine. Most machines don't have that entry, and
        programs there would fail. The guard makes ssh send `xterm-256color`
        instead. To send `xterm-rex` to a machine that does have the entry,
        run `rex terminfo host install HOST`, and run `rex terminfo setup` once
        to write the account's own guard in `~/.config/rex/ssh_config`, which
        lists the hosts you record. This option includes that file ahead of
        the packaged guard, and ssh ignores it until it exists. Outside a Rex
        terminal, the guard does nothing.

        This option works through `programs.ssh`, because home-manager only
        writes `~/.ssh/config` when that module is enabled:

        ```nix
        programs.ssh.enable = true;
        programs.rex.enable = true;
        ```

        If `programs.ssh.enable` is false, the module prints a warning instead.
        You can then run `rex terminfo setup`, which adds the guard to an
        `~/.ssh/config` you manage yourself, and set this option to false to
        silence the warning.

        The guard file comes from `package`. When `package` is null, this
        option is false by default, and setting it to true is an error. To keep
        the guard, run `rex terminfo setup` and include the file it writes:

        ```nix
        programs.ssh.includes = [ "~/.config/rex/ssh_config" ];
        ```
      '';
    };

    config = lib.mkOption {
      type = lib.types.nullOr (lib.types.either lib.types.lines lib.types.path);
      default = null;
      example = lib.literalExpression ''
        '''
          rex.bind("ctrl+b>c", "window.new")
          rex.bind("cmd+d", "pane.split", { direction = "right" })
        '''
      '';
      description = ''
        Your Rex configuration, written to `~/.config/rex/init.lua`. Give the
        Lua source as a string, or a path to an existing file:

        ```nix
        programs.rex.config = ./rex/init.lua;
        ```

        Null, the default, leaves `init.lua` alone, so you can manage it
        yourself. After a change, run `rex config reload` to apply it to a
        running server.
      '';
    };
  };

  options.services.rex = {
    enable =
      (lib.mkEnableOption "a long-running personal Rex server")
      // {
        description = ''
          Whether to run your personal Rex server as a systemd user service
          named `rex`.

          Without this option, the first `rex` command starts a server, and
          that server exits soon after its last session closes. The service
          keeps one running instead, and systemd restarts it if it fails. It
          uses the same socket as every `rex` command, so `rex ls`,
          `rex server status`, and `rex server stop` all reach it.

          The user service starts when you log in and stops when you log out,
          which ends every session. To keep it running while you are logged
          out, turn on lingering for your account once:

          ```sh
          loginctl enable-linger
          ```

          An account that the Rex login server reaches needs lingering too.
          The login server keeps no login session open for this service.
          Without lingering, systemd stops the server, and every program in
          its terminals, a few seconds after each request.

          Read the server's log with `journalctl --user -u rex`.

          `home-manager switch` never restarts a running server, because a
          restart ends every session. After an update, the server keeps
          running the version it started with. Restart it when you are ready
          to use the new one:

          ```sh
          systemctl --user restart rex
          ```

          To restart the server on every switch instead, add:

          ```nix
          systemd.user.services.rex.Unit.X-SwitchMethod = "restart";
          ```

          This option also enables `programs.rex`. It is only available on
          Linux. On macOS, the Rex app runs the server for you.
        '';
      };

    package = lib.mkOption {
      type = lib.types.package;
      # The unit starts the server by its full path, so the service always
      # needs a package. A rex installed outside Nix has no path the module
      # can know, so a null programs.rex.package falls back to the flake's own.
      default =
        if cfg.package != null
        then cfg.package
        else defaultPackage;
      defaultText = lib.literalExpression ''
        if config.programs.rex.package != null
        then config.programs.rex.package
        else rex.packages.''${pkgs.stdenv.hostPlatform.system}.rex
      '';
      description = ''
        The Rex package the service runs. Leave this alone unless you want the
        server and the `rex` command on your `PATH` to be different builds.

        If `programs.rex.package` is null, the service runs the `rex` package
        from the flake you imported the module from. That can be a different
        version from the `rex` command on your `PATH`. Rex works across
        versions, but you can set this option to pick the build yourself.
      '';
    };

    extraListen = lib.mkOption {
      type = lib.types.listOf lib.types.str;
      default = [];
      example = [
        "/run/user/1000/rex/second.sock"
        "127.0.0.1:7297"
      ];
      description = ''
        More addresses for the server to accept connections on, in addition to
        its usual socket. Each entry is one of:

        - An absolute Unix socket path, such as `/run/user/1000/rex/second.sock`,
          or a `unix:///` URL.
        - A TCP address, such as `127.0.0.1:7297`.
        - An `http://` URL with no path, such as `http://127.0.0.1:7298`.

        TCP and HTTP addresses can't tell who is connecting, so they also need
        `allowAnonymous = true`. The server fails to start if it can't listen on
        any of these addresses.
      '';
    };

    allowAnonymous = lib.mkOption {
      type = lib.types.bool;
      default = false;
      description = ''
        Whether to accept connections on the TCP and HTTP addresses in
        `extraListen`. Anyone who can reach one of those addresses gets full
        control of the server, including starting programs as you.

        Configuration fails if `extraListen` has a TCP or HTTP address and this
        option is false. Keep such addresses on `127.0.0.1` or behind a
        firewall. To reach the server from other machines, `tailscale.enable`
        is the safer choice, because Tailscale tells Rex who each caller is.
      '';
    };

    tailscale = {
      enable =
        (lib.mkEnableOption "remote access through Tailscale")
        // {
          description = ''
            Whether to make the server reachable on your tailnet. Rex runs its
            own Tailscale node inside the server, so it doesn't need the
            Tailscale app or daemon on this machine.

            The first time the server starts, it needs to sign in to Tailscale.
            The sign-in link appears in `rex server status` and in the
            server's log. Use `authKeyFile` to sign in without a browser.

            The server's address is `https://<hostname>.<tailnet>.ts.net`, so
            your tailnet needs MagicDNS and HTTPS certificates turned on. From
            another machine on the tailnet:

            ```sh
            rex --server rex.example.ts.net ls
            ```

            By default, only the Tailscale account that enrolled the node can
            connect. See `allowTailnetMembers` to let others in.
          '';
        };

      hostname = lib.mkOption {
        type = lib.types.str;
        default = "rex";
        example = "rex-laptop";
        description = ''
          The machine name the node uses on your tailnet. Each name has its own
          saved identity, so changing it creates a new node that must be
          enrolled again.
        '';
      };

      controlUrl = lib.mkOption {
        type = lib.types.nullOr lib.types.str;
        default = null;
        example = "https://headscale.example.com";
        description = ''
          The control server the node signs in with, such as a self-hosted
          Headscale server. Null uses Tailscale's own. Each control server
          keeps its own saved identity, so changing this enrolls a new node.

          Rex serves your tailnet only over HTTPS, with certificates from the
          control server. Headscale doesn't issue those yet.
        '';
      };

      allowTailnetMembers = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = ''
          Whether anyone on your tailnet whom your Tailscale access rules allow
          may connect. When false, only the Tailscale account that enrolled the
          node can connect. Requires `tailscale.enable`.
        '';
      };

      authKeyFile = lib.mkOption {
        type = lib.types.nullOr (lib.types.either lib.types.path lib.types.str);
        default = null;
        example = "/run/user/1000/secrets/rex-tailscale-auth-key";
        description = ''
          A file holding a Tailscale auth key, used to enroll the node without
          opening a sign-in link. Requires `tailscale.enable`.

          The key matters only for the first enrollment. The node then keeps
          its identity in Rex's state directory and ignores the key on later
          starts, so a one-time key is enough.

          Keep the file out of the Nix store, because every user on the machine
          can read store files. A secrets tool such as sops-nix or agenix is a
          good fit. The service reads the file through a systemd credential,
          which needs systemd 250 or newer.
        '';
      };

      advertiseTags = lib.mkOption {
        type = lib.types.listOf (lib.types.strMatching "tag:[A-Za-z][A-Za-z0-9-]*");
        default = [];
        example = ["tag:rex"];
        description = ''
          Tailscale tags for the node to request when it enrolls, each written
          as `tag:name`. Your access rules can then refer to the server by tag.
          The auth key must be allowed to grant every tag listed. Like the auth
          key, tags apply only to the first enrollment.

          A tagged node belongs to no Tailscale account, so the default "only
          the owner may connect" rule would let nobody in. Tags therefore
          require `allowTailnetMembers` as well:

          ```nix
          services.rex.tailscale = {
            enable = true;
            allowTailnetMembers = true;
            advertiseTags = [ "tag:rex" ];
          };
          ```
        '';
      };
    };

    webSocketOriginPatterns = lib.mkOption {
      type = lib.types.listOf lib.types.str;
      default = [];
      example = [
        "https://rex.example.com"
        "https://*.example.net"
      ];
      description = ''
        Web pages, besides the server's own address, that may connect to the
        server from a browser. Each entry is a pattern where `*` matches any
        text, compared without regard to case. A pattern without `://` matches
        only the host name. A pattern with `://` matches the scheme and host
        together.

        Keep these narrow. A page that matches can control the server from the
        browser of anyone who visits it.
      '';
    };

    blockDirs = lib.mkOption {
      type = lib.types.listOf lib.types.str;
      default = [];
      example = ["/home/alice/rex-blocks"];
      description = ''
        Directories to search, in order, for block plugin programs. The empty
        default searches `rex/blocks` under `$XDG_DATA_HOME`, usually
        `~/.local/share/rex/blocks`, and then under each `$XDG_DATA_DIRS`
        entry. A non-empty list replaces that search.
      '';
    };

    reloadBlockPlugins = lib.mkOption {
      type = lib.types.bool;
      default = false;
      description = ''
        Whether to restart a block plugin when its program changes on disk.
        This is useful while developing a plugin. The server itself keeps
        running.
      '';
    };

    logFormat = lib.mkOption {
      type = lib.types.enum [
        "text"
        "json"
      ];
      default = "text";
      description = ''
        How the server writes log messages: `text` for people, or `json` for
        log tools. Read the log with `journalctl --user -u rex`.
      '';
    };

    maxSessions = limitOption {
      what = "sessions";
      scope = "the server holds at once";
      rexDefault = 64;
    };
    maxBlocks = limitOption {
      what = "blocks, such as terminals,";
      scope = "the server holds at once across all sessions";
      rexDefault = 1024;
    };
    maxWindows = limitOption {
      what = "windows";
      scope = "in one session";
      rexDefault = 64;
    };
    maxPanes = limitOption {
      what = "panes";
      scope = "in one window";
      rexDefault = 64;
    };

    extraArgs = lib.mkOption {
      type = lib.types.listOf lib.types.str;
      default = [];
      example = ["--verbose"];
      description = ''
        More arguments for `rex server run`, added after all the others. Use
        this for flags that have no option here. Run `rex server run --help`
        to see them all.

        Configuration fails if an entry repeats a flag that an option already
        sets, so the options stay the single source of truth. `--listen` and
        `--state-dir` are refused too. The service leaves them out on purpose,
        so the server uses the same socket and files as your `rex` commands.
      '';
    };

    environment = lib.mkOption {
      type = lib.types.attrsOf lib.types.str;
      default = {};
      example = {
        GODEBUG = "http2debug=1";
      };
      description = ''
        Environment variables for the server and for the programs it starts.
        The module already sets `TERMINFO_DIRS`, so programs can find
        `xterm-rex`, and clears `GODEBUG`, so a value inherited from the system
        can't stop the server from starting. It also sets
        `REX_CGROUP_DELEGATED` to `1`, which gives each terminal a cgroup of
        its own. A variable set here replaces the module's value, so this
        turns the cgroups off:

        ```nix
        services.rex.environment.REX_CGROUP_DELEGATED = "0";
        ```
      '';
    };
  };

  config = lib.mkMerge [
    (lib.mkIf cfg.enable {
      home.packages = lib.optional (cfg.package != null) cfg.package;

      assertions = [
        {
          assertion = cfg.terminfo -> cfg.package != null;
          message = ''
            programs.rex.terminfo is true, but programs.rex.package is null.
            The module installs the terminfo entry from the package. Remove
            the programs.rex.terminfo setting, and run `rex terminfo setup` to
            install the entry instead.
          '';
        }
        {
          assertion = cfg.sshGuard -> cfg.package != null;
          message = ''
            programs.rex.sshGuard is true, but programs.rex.package is null.
            The module installs the ssh guard from the package. Remove the
            programs.rex.sshGuard setting, and run `rex terminfo setup` to
            install the guard instead.
          '';
        }
      ];

      # Linux files a terminfo entry under its first letter, x/xterm-rex. macOS
      # file systems usually ignore case, so macOS uses the letter's hex code
      # instead, 78/xterm-rex. Writing both matches internal/terminfo.Install,
      # so `rex terminfo setup` finds the same bytes and leaves them alone.
      #
      # home-manager can also point TERMINFO_DIRS at the profile, but only on
      # Darwin or with targets.genericLinux, and only in login shells. Every
      # terminfo reader looks in ~/.terminfo, so the files work everywhere.
      #
      # The entry's short name, rex, gets the same two files. That way
      # `infocmp rex` works, and `rex terminfo setup` finds nothing to add.
      home.file = lib.mkIf cfg.terminfo {
        ".terminfo/x/xterm-rex".source = terminfoEntry;
        ".terminfo/78/xterm-rex".source = terminfoEntry;
        ".terminfo/r/rex".source = terminfoAlias;
        ".terminfo/72/rex".source = terminfoAlias;
      };

      # home-manager writes `includes` as one Include line at the top of
      # ~/.ssh/config, before any Host block. The guard is a Match block, which
      # only works there. extraConfig would land after the Host blocks. Being
      # first also matters because ssh keeps the first value it sees for each
      # setting, so the guard's SetEnv TERM wins over a later one.
      #
      # The account's own guard comes first. The packaged guard downgrades
      # every host until the account's guard exists, and then defers to it, so
      # this order lets recorded hosts through. ssh skips an included file
      # that does not exist.
      programs.ssh.includes =
        lib.mkIf (cfg.sshGuard && config.programs.ssh.enable) [accountGuardFile sshGuardFile];

      # The option's type accepts text or a path. A Nix path, or a string that
      # names a store path, is linked as a file. Anything else is the Lua
      # source itself.
      xdg.configFile."rex/init.lua" = lib.mkIf (cfg.config != null) (
        if builtins.isPath cfg.config || lib.isStorePath cfg.config
        then {source = cfg.config;}
        else {text = cfg.config;}
      );

      warnings = lib.optional (cfg.sshGuard && !config.programs.ssh.enable) ''
        programs.rex: the Rex ssh guard was not installed, because
        programs.ssh.enable is false. Without the guard, ssh from a Rex terminal
        sends TERM=xterm-rex to machines that may not know it. To fix this,
        set programs.ssh.enable = true, or run `rex terminfo setup` to add the
        guard to your own ~/.ssh/config. Set programs.rex.sshGuard = false to
        hide this warning.
      '';
    })
    (lib.mkIf serverCfg.enable {
      programs.rex.enable = lib.mkDefault true;

      assertions = [
        {
          assertion = pkgs.stdenv.hostPlatform.isLinux;
          message = ''
            services.rex.enable works only on Linux, because it runs the server
            as a systemd user service. On macOS, the Rex app runs the server for
            you. Use programs.rex.enable to install the rex command.
          '';
        }
        {
          assertion = hasTcpListener -> serverCfg.allowAnonymous;
          message = ''
            services.rex.extraListen has a TCP or http:// address, which needs
            services.rex.allowAnonymous = true. Anyone who can reach such an
            address gets full control of the server.
          '';
        }
        {
          assertion = managedExtraArgs == [];
          message = ''
            services.rex.extraArgs sets flags that the module manages:
            ${lib.concatStringsSep ", " managedExtraArgs}. Use the matching
            services.rex option instead. --listen and --state-dir have no
            option, because the service must use the same socket and files as
            your rex commands.
          '';
        }
        {
          assertion = serverCfg.tailscale.allowTailnetMembers -> serverCfg.tailscale.enable;
          message = ''
            services.rex.tailscale.allowTailnetMembers needs
            services.rex.tailscale.enable = true.
          '';
        }
        {
          assertion = serverCfg.tailscale.authKeyFile != null -> serverCfg.tailscale.enable;
          message = ''
            services.rex.tailscale.authKeyFile needs
            services.rex.tailscale.enable = true.
          '';
        }
        {
          assertion = serverCfg.tailscale.advertiseTags != [] -> serverCfg.tailscale.enable;
          message = ''
            services.rex.tailscale.advertiseTags needs
            services.rex.tailscale.enable = true.
          '';
        }
        {
          assertion = serverCfg.tailscale.advertiseTags != [] -> serverCfg.tailscale.allowTailnetMembers;
          message = ''
            services.rex.tailscale.advertiseTags needs
            services.rex.tailscale.allowTailnetMembers = true. A tagged node
            belongs to no Tailscale account, so allowing only its owner would
            let nobody connect.
          '';
        }
      ];

      # Lingering is state on the machine that runs the service, and
      # `loginctl enable-linger` changes it without touching any Nix option.
      # Evaluation can't see it and often runs on a different machine, so a
      # warning there would print on every evaluation, even with lingering on.
      # Activation runs on the right machine. It reads logind's file instead of
      # asking loginctl because activation can run at boot, before logind is up.
      home.activation.rexLingerNotice = lib.hm.dag.entryAfter ["writeBoundary"] ''
        if [[ ! -e /var/lib/systemd/linger/${lib.escapeShellArg config.home.username} ]]; then
          warnEcho "services.rex: lingering is off, so the Rex server stops when you log out, which ends every session. To keep it running while you are logged out, run: loginctl enable-linger"
        fi
      '';

      systemd.user.services.rex = {
        Unit = {
          Description = "Rex Server";
          Documentation = ["https://superlogical.com"];
          After = ["network-online.target"];
          # By default, home-manager restarts a user service whose unit file
          # changed, and every package update changes this one. A restart ends
          # every session, so the running server stays up until the user
          # restarts it. systemd has loaded the new unit file by then, so that
          # restart runs the new package. mkDefault lets a user choose
          # "restart" with a plain assignment, as the enable option shows.
          X-SwitchMethod = lib.mkDefault "keep-old";
        };

        Service = {
          # Rex starts programs for its clients, and any sandboxing here would
          # also confine those programs. The account itself is the boundary.
          #
          # Rex tells systemd when it is ready for clients, and
          # `systemctl --user start rex` waits for that. A command run right
          # after it, such as `rex server status`, always finds the server.
          Type = "notify";
          NotifyAccess = "main";
          # No --listen and no --state-dir. The user manager sets
          # XDG_RUNTIME_DIR, so the server picks the same socket and state
          # directory as every rex command for this account. That is how
          # `rex server status` and `rex server stop` find it, and why a rex
          # command uses it instead of starting a second server.
          ExecStart = execStart;
          Environment = lib.mapAttrsToList environmentAssignment serverEnvironment;
          LoadCredential =
            lib.mkIf (serverCfg.tailscale.authKeyFile != null)
            ["${tailscaleAuthKeyCredential}:${toString serverCfg.tailscale.authKeyFile}"];
          Restart = "on-failure";
          RestartSec = "5s";
          # Stopping the service sends SIGTERM to the server alone. The server
          # saves every session and then closes its terminals, and systemd sends
          # SIGKILL to anything left once the server exits. The default,
          # control-group, would also send SIGTERM to every program in the
          # server's terminals. Shells such as fish exit on it, and their windows
          # would not be saved. internal/install/units/rex.service explains
          # this setting at more length.
          KillMode = "mixed";
          # A program that the kernel kills for using too much memory must not
          # stop the whole unit and close every other terminal. Rex terminals
          # run login shells, and logind runs login shells at an OOM score
          # adjustment of 0, so this unit asks for 0 too. On systemd 250 and
          # later the kernel raises it to 100, which is expected.
          # internal/install/units/rex.service explains both settings at more
          # length.
          OOMPolicy = "continue";
          OOMScoreAdjust = 0;
          # Hand the unit's cgroup to the server. It runs itself in server/
          # and each terminal in a cgroup of its own, so systemd-oomd can kill
          # one terminal instead of every session. systemd before 254 ignores
          # DelegateSubgroup, and the server then moves itself into server/.
          # internal/install/units/rex.service explains both settings at more length.
          Delegate = true;
          DelegateSubgroup = "server";
        };

        Install.WantedBy = ["default.target"];
      };
    })
  ];
}
