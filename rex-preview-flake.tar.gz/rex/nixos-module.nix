self: {
  config,
  lib,
  pkgs,
  ...
}: let
  cfg = config.services.rex;
  loginCfg = cfg.loginServer;

  stateDir = "/var/lib/rex";
  runtimeDir = "/run/rex";
  defaultSocketPath = "${runtimeDir}/server.sock";
  loginServerSocketPath = "${runtimeDir}/login-server.sock";

  # The module is exported from this flake, so default to the matching Rex
  # package for the target host platform. Callers can still override `package`
  # when testing a local wrapper or using an overlay-provided build.
  defaultPackage =
    self.packages.${pkgs.stdenv.hostPlatform.system}.rex
    or self.packages.${pkgs.system}.rex;

  # Rex carries its own terminfo entry, xterm-rex, and an ssh_config block that
  # keeps that terminal type from reaching hosts which cannot resolve it. The
  # Rex package installs both; see nix/package.nix.
  terminfoDir = "${cfg.package}/share/terminfo";
  sshGuardFile = "${cfg.package}/share/rex/ssh_config.d/50-rex.conf";

  # TERMINFO_DIRS for a Rex unit, so that programs started in a terminal which
  # claims xterm-rex can look that name up.
  #
  # The server reads this variable twice over. It decides whether to claim the
  # name at all by searching its own environment (internal/terminfo.Lookup),
  # because its own environment is what a child inherits, and the child then
  # needs that same search to succeed. Neither works here by default. A systemd
  # unit gets none of the TERMINFO_DIRS that NixOS gives login shells through
  # /etc/profile, and /usr/share/terminfo, where the search would otherwise
  # end up, does not exist on NixOS at all.
  #
  # The empty element at the end is not a typo. ncurses reads it as "and then
  # the compiled-in defaults", which is what keeps ordinary entries such as
  # xterm-256color and linux resolvable for the programs a terminal starts.
  # Without it this one directory would be the whole database. Rex's own search
  # reads an empty element the same way.
  terminfoDirs = "${terminfoDir}:";

  # Build the primary TCP endpoint so an IPv6 address receives
  # the brackets required to separate it from the port.
  tcpEndpoint =
    if lib.hasInfix ":" cfg.listenAddress && !lib.hasPrefix "[" cfg.listenAddress
    then "[${cfg.listenAddress}]:${toString cfg.port}"
    else "${cfg.listenAddress}:${toString cfg.port}";

  # A non-null socket path selects local access. Setting it to null selects the
  # TCP endpoint assembled above.
  listenEndpoint =
    if cfg.socketPath != null
    then cfg.socketPath
    else tcpEndpoint;

  # `extraArgs` remains useful for new or uncommon CLI switches. Do not let it
  # repeat flags represented by module options because the effective service
  # configuration would no longer match those option values. Listener and state
  # overrides could also bypass the firewall and persistence settings below.
  managedServeFlags = [
    "--listen"
    "--socket-mode"
    "--allow-anonymous"
    "--tailnet-allow-identified"
    "--tailscaled-socket"
    "--extra-listen"
    "--state-dir"
    "--websocket-origin-pattern"
    "--block-dir"
    "--block-plugin-reload"
    "--log-format"
    "--tailscale"
    "--tailscale-hostname"
    "--tailscale-control-url"
    "--tailscale-allow-tailnet-members"
    "--tailscale-auth-key-file"
    "--tailscale-advertise-tag"
  ];

  # The auth key reaches the service through a systemd credential instead of a
  # world-readable unit file: LoadCredential copies the secret into the
  # service's private credentials directory, and the %d specifier resolves to
  # that directory ($CREDENTIALS_DIRECTORY) at service start.
  tailscaleAuthKeyCredential = "tailscale-auth-key";
  isManagedServeArg = arg:
    lib.any (flag: arg == flag || lib.hasPrefix "${flag}=" arg) managedServeFlags;
  managedExtraArgs = lib.filter isManagedServeArg cfg.extraArgs;

  # Tags, like the auth key, are used only during enrollment. `rex server run`
  # rejects them without --tailscale. The assertion below already ties them to
  # tailscale.enable. This guard keeps the generated command consistent with
  # the option that controls the listener.
  tailscaleAdvertiseTagArgs =
    lib.optionals cfg.tailscale.enable
    (lib.concatMap (tag: ["--tailscale-advertise-tag" tag]) cfg.tailscale.advertiseTags);

  # The host's tailscaled identifies callers on tailnet and Serve listeners.
  # Only plain HTTP and bare host:port endpoints need anonymous admission.
  isUnixEndpoint = endpoint: lib.hasPrefix "/" endpoint || lib.hasPrefix "unix://" endpoint;
  isTailnetEndpoint = endpoint:
    lib.hasPrefix "tailnet://" (lib.toLower endpoint)
    || lib.hasPrefix "tailnet-serve://" (lib.toLower endpoint);
  hasTcpListener =
    cfg.socketPath
    == null
    || lib.any (endpoint: !isUnixEndpoint endpoint && !isTailnetEndpoint endpoint) cfg.extraListen;
  hasHostTailnetListener = cfg.tailscaleServe.enable || lib.any isTailnetEndpoint cfg.extraListen;

  # Tailscale Serve takes its port inside tailscaled, before the connection
  # reaches the host's network stack. A `tailnet://` listener on the same port
  # would therefore never receive a tailnet connection, so evaluation refuses
  # the pair instead of letting the listener fail silently at runtime.
  #
  # Rex requires a port on every `tailnet://` address, so there is no default
  # port to account for. The port is compared as text with leading zeros
  # removed, because Rex reads `07297` as 7297. It is not converted to an
  # integer, so an out-of-range port still reaches Rex and fails there with a
  # clear message instead of failing here with a Nix conversion error. Named
  # ports, such as `tailnet://:https`, are not looked up and never match.
  tailnetEndpointPort = endpoint: let
    match = builtins.match "tailnet://.*:0*([0-9]+)" (lib.toLower endpoint);
  in
    if match == null
    then null
    else builtins.head match;
  servePortCollisions = serve: endpoints:
    lib.optionals serve.enable
    (lib.filter (endpoint: tailnetEndpointPort endpoint == toString serve.httpsPort) endpoints);
  servePortCollisionMessage = prefix: serve: collisions:
    "${prefix}.tailscaleServe.httpsPort and ${prefix}.extraListen both use port "
    + "${toString serve.httpsPort} (${lib.concatStringsSep ", " collisions}). Tailscale Serve "
    + "takes that port for every tailnet connection to this host, so the listener would never "
    + "receive one. Give the listener another port, or set ${prefix}.tailscaleServe.httpsPort "
    + "to another port.";
  extraListen =
    cfg.extraListen
    ++ lib.optional cfg.tailscaleServe.enable "tailnet-serve://${cfg.tailscaleServe.socketPath}";

  # The login server shares host identity discovery with `rex server run`. Its
  # accounts file controls access, so these flags must stay consistent with the
  # generated policy, runtime directory, and Tailscale Serve mapping.
  managedLoginServerFlags = [
    "--listen"
    "--accounts"
    "--runtime-root"
    "--log-format"
    "--tailscaled-socket"
    "--allow-anonymous"
    "--extra-listen"
    "--pam"
    "--pam-service"
  ];
  managedLoginServerExtraArgs =
    lib.filter
    (arg: lib.any (flag: arg == flag || lib.hasPrefix "${flag}=" arg) managedLoginServerFlags)
    loginCfg.extraArgs;
  loginServerHasHostTailnetListener =
    loginCfg.tailscaleServe.enable || lib.any isTailnetEndpoint loginCfg.extraListen;
  loginServerExtraListen =
    loginCfg.extraListen
    ++ lib.optional loginCfg.tailscaleServe.enable
    "tailnet-serve://${loginCfg.tailscaleServe.socketPath}";
  loginServerAccountsFile =
    if loginCfg.accountsFile == null
    then "/etc/rex/accounts.jsonc"
    else toString loginCfg.accountsFile;

  # Serve persists its background configuration. Stop removes only the HTTPS
  # port owned by this unit, preserving the host's other Serve mappings. Both
  # server modes use the same unit so switching modes also changes its dependency.
  #
  # systemd marks tailscaled as started as soon as its process is running, which
  # can be several seconds before it reconnects to the tailnet. `tailscale serve`
  # fails if it runs in that window. This happens on every deploy that restarts
  # tailscaled, because Requires= restarts this unit right after it, and it can
  # happen on a slow boot. A oneshot unit that fails stays failed, so Serve would
  # stay off until someone restarted the unit by hand.
  #
  # Two settings close that gap. `tailscale wait` holds the unit until tailscaled
  # is connected and has a Tailscale IP, which handles the common case. Restart
  # handles the rare case where tailscaled drops again between the wait and the
  # serve command. RestartSec is 5 seconds because systemd stops restarting a
  # unit that starts 5 times within 10 seconds. A shorter delay could reach that
  # limit and leave the unit failed, which is the outcome this is here to avoid.
  #
  # `unit` is the Rex unit that provides the Serve socket. Normally that is the
  # service, which creates the socket when it starts. With socket activation it
  # is the socket unit instead: systemd holds the Serve socket, so the first
  # tailnet request starts the server. Requiring the service there would start
  # the server at boot and defeat the option.
  tailscaleServeService = {
    httpsPort,
    socketPath,
    unit,
  }: {
    description = "Rex Tailscale Serve";
    after = ["tailscaled.service" unit];
    requires = ["tailscaled.service" unit];
    wantedBy = ["multi-user.target"];
    serviceConfig = let
      tailscaleCommand =
        [(lib.getExe config.services.tailscale.package)]
        ++ lib.optionals (cfg.tailscaledSocket != null) [
          "--socket=${toString cfg.tailscaledSocket}"
        ];
    in {
      Type = "oneshot";
      RemainAfterExit = true;
      ExecStartPre = lib.escapeShellArgs (tailscaleCommand ++ ["wait"]);
      ExecStart = lib.escapeShellArgs (tailscaleCommand
        ++ [
          "serve"
          "--bg"
          "--https=${toString httpsPort}"
          "unix:${socketPath}"
        ]);
      ExecStop = lib.escapeShellArgs (tailscaleCommand
        ++ [
          "serve"
          "--https=${toString httpsPort}"
          "off"
        ]);
      Restart = "on-failure";
      RestartSec = 5;
    };
  };

  # An empty interface list opens the configured port everywhere. A non-empty
  # list creates one rule per interface, which lets callers limit the listener
  # to a specific network such as a host-managed Tailscale connection.
  firewallConfig =
    if cfg.openFirewallInterfaces == []
    then {
      allowedTCPPorts = [cfg.port];
    }
    else {
      interfaces = lib.genAttrs cfg.openFirewallInterfaces (_: {
        allowedTCPPorts = [cfg.port];
      });
    };
in {
  options.services.rex = {
    enable = lib.mkEnableOption "the Rex server";

    loginServer = {
      enable =
        (lib.mkEnableOption "the Rex login server")
        // {
          description = ''
            Whether to run one root process that names callers through the host's
            tailscaled, maps them to operating system accounts, and runs one Rex
            server per account as that account. Declare the target accounts yourself
            and configure `accounts` or `accountsFile`. This must not be combined
            with `services.rex.enable`.
          '';
        };

      socketActivation = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = ''
          Whether systemd holds the login server's socket,
          `/run/rex/login-server.sock`, and starts the login server when the
          first client connects, instead of at boot. The module then adds a
          `rex-login-server.socket` unit and leaves `rex-login-server.service`
          out of `multi-user.target`. The first client waits a moment while the
          login server starts, then works as usual. Only root can connect to the
          socket, as before.

          The module keeps the socket unit's `ListenStream=` and the login
          server's `--listen` in agreement. With `tailscaleServe.enable`, the
          socket unit also holds the Serve socket, so a tailnet request starts
          the login server too. Other `extraListen` endpoints are opened by the
          login server when it starts.

          While `rex-login-server.socket` is active, any connection starts the
          login server again, so stopping the service alone lasts only until
          the next client connects. To stop it and keep it stopped until the
          next boot:

          ```
          systemctl stop rex-login-server.socket rex-login-server.service
          ```

          The account servers it started keep running either way. Policy
          changes still reload a running login server. When none is running,
          the next one reads the new policy as it starts. This requires
          `loginServer.enable`.
        '';
      };

      pam = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = ''
          Whether the login server opens PAM sessions and runs PAM account checks.
          False passes `--pam=false`, declares no PAM service, and gives up the
          logind session, limits, and environment modules. Intended for containers
          and hosts without PAM; shadow-based account checks still run.
        '';
      };

      accounts = lib.mkOption {
        type = lib.types.attrsOf (lib.types.submodule {
          options.principals = lib.mkOption {
            type = lib.types.listOf lib.types.str;
            default = [];
            description = ''
              Principal keys allowed to act as this account. Membership is a set:
              any matching key grants access, and an empty list grants none.
              Keys may select a Tailscale login or tag, a `peer:<uid>`,
              `tailscale:*`, `tailscale:tag:*`, `identified`, or `anonymous`.
              Anonymous callers cannot act as a UID 0 account, and `anonymous`
              must not appear under the wildcard account `*`.
            '';
          };
        });
        default = {};
        description = ''
          Operating system accounts and the principals allowed to act as each.
          The module writes these to `/etc/rex/accounts.jsonc`; it does not create
          the accounts. Declare them with `users.users.<name>` separately.
          Policy changes reload the login server and close connections whose
          selected account is no longer allowed, preserving persistent sessions.
          The account `*` grants matching callers access to any regular account
          with UID at least 1000. Named and wildcard grants are additive.
          Configure at least one account unless using `accountsFile`, which
          requires this option to be empty.
        '';
      };

      defaults = lib.mkOption {
        type = lib.types.attrsOf lib.types.str;
        default = {};
        description = ''
          Principal keys mapped to the account chosen when a client names none.
          Each value must name an entry in `accounts` and must not be `*`.
          A default selects an account but does not grant permission to use it.
          More specific keys take precedence; equally specific keys follow the
          generated JSON's attribute order. Use `accountsFile` for explicit file
          ordering, leaving this option and `accounts` empty.
        '';
      };

      accountsFile = lib.mkOption {
        type = lib.types.nullOr lib.types.path;
        default = null;
        example = "/etc/rex/hand-written.jsonc";
        description = ''
          Existing HuJSON accounts file to load instead of generating
          `/etc/rex/accounts.jsonc`. The file must be readable by root at service
          startup and include `"version": 1`. Both `accounts` and `defaults`
          must be empty when this option is set. Rex validates the file at startup.
          After changing an external file in place, run `systemctl reload
          rex-login-server` or send SIGHUP to the login server's main PID.
        '';
      };

      extraListen = lib.mkOption {
        type = lib.types.listOf lib.types.str;
        default = [];
        description = ''
          Additional login server endpoints: absolute Unix socket paths,
          `unix:///` URLs, `http://` URLs, bare `host:port` addresses,
          `tailnet://IP:port`, or `tailnet-serve:///absolute/path`.
          Tailnet schemes require `services.tailscale.enable`; plain TCP and
          HTTP require `allowAnonymous`. Tagged callers must use `tailnet://`
          because Serve does not forward their identity. When
          `tailscaleServe.enable` is true, a `tailnet://` address must use a
          different port than `tailscaleServe.httpsPort`, because Serve takes
          that port for all tailnet traffic to the host. Do not use
          `login-server://`, which is reserved for account servers.
          This option does not open firewall ports. Custom socket parent
          directories must already exist and permit root to create the sockets.
        '';
      };

      allowAnonymous = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = ''
          Whether to accept anonymous callers on plain TCP and HTTP listeners.
          Required for any such endpoint in `extraListen`. These callers can
          reach only accounts whose principals include `anonymous`; UID 0
          accounts and the wildcard account cannot admit them. Limit who can
          connect through listener addresses and firewall rules.
        '';
      };

      tailscaleServe = {
        enable =
          (lib.mkEnableOption "Tailscale Serve access to the Rex login server")
          // {
            description = ''
              Whether to manage an HTTPS mapping through the host's Tailscale
              Serve to the login server's dedicated Unix socket. This requires
              `services.tailscale.enable`, an enrolled host with HTTPS available,
              and accounts allowing the callers. Tagged callers require a
              `tailnet://` listener instead. This must not be combined with the
              ordinary Rex server.

              The mapping is managed by the `rex-tailscale-serve` systemd unit.
              It is described under `services.rex.tailscaleServe.enable`, and
              behaves the same way here.
            '';
          };
        httpsPort = lib.mkOption {
          type = lib.types.port;
          default = 7297;
          example = 443;
          description = ''
            The tailnet HTTPS port on which Tailscale Serve forwards to the
            login server. Used only when `tailscaleServe.enable` is true.

            Do not add your own Serve mapping on this port. The module's Serve
            unit manages it and removes it when the unit stops.

            The default is 7297 rather than 443 for the same reason given under
            `services.rex.tailscaleServe.httpsPort`. Serve takes its port for
            every tailnet connection to the host, so a web server already on
            443 would stop receiving tailnet traffic. Clients still need only
            the hostname, because the Rex CLI tries both 443 and 7297.
            Use `443` when nothing else on the host serves HTTPS to the tailnet.
          '';
        };
        socketPath = lib.mkOption {
          type = lib.types.str;
          default = "${runtimeDir}/serve.sock";
          description = ''
            Absolute path of the login server's dedicated Serve socket, created
            as root with mode `0600`. Used only when `tailscaleServe.enable` is
            true. A custom parent directory must already exist. Rex verifies
            the forwarding process against the owner of tailscaled's LocalAPI
            socket before accepting its forwarded identity.
          '';
        };
      };

      extraArgs = lib.mkOption {
        type = lib.types.listOf lib.types.str;
        default = [];
        example = ["--verbose"];
        description = ''
          Additional arguments passed to `rex login-server`. Use this only for
          flags without a dedicated module option. Do not set `--listen`,
          `--accounts`, `--runtime-root`, `--log-format`, `--tailscaled-socket`,
          `--allow-anonymous`, or `--extra-listen` here. Evaluation rejects them.
        '';
      };
    };

    package = lib.mkOption {
      type = lib.types.package;
      default = defaultPackage;
      defaultText =
        lib.literalExpression
        "rex.packages.\${pkgs.stdenv.hostPlatform.system}.rex";
      description = "The Rex package to use for the service.";
    };

    installClient = lib.mkOption {
      type = lib.types.bool;
      default = true;
      description = "Whether to install the service's Rex package in the system profile.";
    };

    user = lib.mkOption {
      type = lib.types.str;
      default = "rex";
      description = ''
        The user account under which Rex runs. The module creates a system user
        when this is `rex`. Any other account must already exist.
      '';
    };

    group = lib.mkOption {
      type = lib.types.str;
      default = "rex";
      description = ''
        The group under which Rex runs. The module creates the group when this
        is `rex`. Any other group must already exist. With the default
        `socketMode`, members of this group can access the Unix sockets.
      '';
    };

    listenAddress = lib.mkOption {
      type = lib.types.str;
      default = "127.0.0.1";
      example = "::1";
      description = ''
        The IP address or host name for the TCP listener. This option is used
        only when `socketPath` is null. IPv6 addresses may be written without
        brackets. The module adds them when it constructs the endpoint.
      '';
    };

    port = lib.mkOption {
      type = lib.types.port;
      default = 8080;
      description = ''
        The port for the TCP listener. This option is used only when
        `socketPath` is null. It is also the port opened by `openFirewall`.
      '';
    };

    socketPath = lib.mkOption {
      type = lib.types.nullOr lib.types.str;
      default = defaultSocketPath;
      example = "/run/rex/server.sock";
      description = ''
        The absolute path of the Unix socket on which Rex listens. Set this to
        null to use the TCP listener configured by `listenAddress` and `port`.
        The module creates `/run/rex` for the default path. For another path,
        its parent directory must already exist and allow the service to create
        the socket. Members of `group` must also be able to traverse that parent
        directory.
      '';
    };

    socketActivation = lib.mkOption {
      type = lib.types.bool;
      default = false;
      description = ''
        Whether systemd holds the server's socket and starts the server when the
        first client connects, instead of at boot. The module then adds a
        `rex.socket` unit that listens on `socketPath` and leaves `rex.service`
        out of `multi-user.target`. The first client waits a moment while the
        server starts, then works as usual. Access is unchanged: the socket gets
        `user`, `group`, and `socketMode`.

        The module keeps the socket unit's `ListenStream=` and the server's
        `--listen` in agreement. With `tailscaleServe.enable`, the socket unit
        also holds the Serve socket, so a tailnet request starts the server too.
        Other `extraListen` endpoints are opened by the server when it starts.

        While `rex.socket` is active, any connection starts the server again,
        so stopping `rex.service` alone lasts only until the next client
        connects. To stop the server and keep it stopped until the next boot:

        ```
        systemctl stop rex.socket rex.service
        ```

        This requires `enable` and a Unix `socketPath`. A TCP primary listener
        cannot be socket activated.
      '';
    };

    socketMode = lib.mkOption {
      type = lib.types.strMatching "0?[0-7][0-7]0";
      default = "0660";
      example = "0600";
      description = ''
        The three- or four-digit octal permission mode for ordinary Unix sockets,
        including those in `extraListen`. Only owner and group bits are allowed.
        The default grants the service user and group access. Use `0600` for
        access by the service user only. A zero mode uses Rex's `0600` default.
        TCP listeners ignore this setting. The dedicated `tailnet-serve://` socket
        always uses `0600`, independent of this option.

        Group access also requires a parent directory the group can traverse.
        Socket access grants the full Rex API, including the ability to start
        workloads as the service user.
      '';
    };

    allowAnonymous = lib.mkOption {
      type = lib.types.bool;
      default = false;
      description = ''
        Whether to admit anonymous callers on plain TCP listeners with full
        access, including the ability to start workloads as the service user.
        Required when `socketPath` is null or `extraListen` contains a bare
        `host:port` or `http://` endpoint. Limit who can connect with a loopback
        address or firewall rules. For identified remote access, prefer the
        host's Tailscale through `tailnet://` or `tailscaleServe`.
      '';
    };

    tailnetAllowIdentified = lib.mkOption {
      type = lib.types.bool;
      default = false;
      description = ''
        Whether to admit every identified caller permitted by Tailscale access
        rules on `tailnet://` and `tailnet-serve://` listeners. By default, only
        the host Tailscale node's owning account is admitted. Tagged hosts have
        no person as their owner and require this option.

        Admitted callers can manage sessions and run workloads as the Rex service user.
        Tagged callers must use `tailnet://` because Serve does not forward
        their identity. The embedded node uses `tailscale.allowTailnetMembers`
        independently of this option.
      '';
    };

    tailscaledSocket = lib.mkOption {
      type = lib.types.nullOr lib.types.path;
      default = null;
      example = "/run/tailscale/tailscaled.sock";
      description = ''
        Path to the host tailscaled daemon's LocalAPI socket. Null selects the
        platform default. Rex and the generated Tailscale Serve commands use
        this path so they consult the same daemon.
      '';
    };

    tailscaleServe = {
      enable =
        (lib.mkEnableOption "identified remote access through the host's Tailscale Serve")
        // {
          description = ''
            Whether to make Rex reachable over HTTPS through the host's Tailscale
            Serve. Tailscale tells Rex who each caller is, so Rex can identify
            callers without a separate login. This requires
            `services.tailscale.enable` and a host that is logged in to a tailnet
            with HTTPS certificates enabled.

            The module creates a `rex-tailscale-serve` systemd unit that runs
            `tailscale serve` when it starts and removes the mapping when it
            stops. It removes only the mapping on `httpsPort`, so other Serve
            mappings on the host are left alone.

            The unit waits for tailscaled to connect to the tailnet before it
            runs `tailscale serve`, using `tailscale wait`. This lets it start
            cleanly at boot and after a deploy that restarts tailscaled. If
            the command still fails, systemd retries it every few seconds. The
            Tailscale package must provide `tailscale wait`.

            To check the unit or see why it failed:

            ```
            systemctl status rex-tailscale-serve
            journalctl -u rex-tailscale-serve
            ```
          '';
        };
      httpsPort = lib.mkOption {
        type = lib.types.port;
        default = 7297;
        example = 443;
        description = ''
          The tailnet HTTPS port on which Tailscale Serve forwards to Rex.
          Used only when `tailscaleServe.enable` is true.

          Serve takes this port for every tailnet connection to the host,
          before any program on the host sees the connection. If a web server
          such as nginx also listens on this port, tailnet visitors reach Rex
          instead of the web server. That is why the default is 7297 and not
          the standard HTTPS port, 443.

          Clients do not need to know the port. Given only a hostname, or an
          `https://` URL without a port, the Rex CLI tries both 443 and 7297:

          ```
          rex --server myhost.example.ts.net ls
          ```

          If nothing else on the host serves HTTPS to the tailnet, you can use
          the standard port instead:

          ```nix
          services.rex.tailscaleServe = {
            enable = true;
            httpsPort = 443;
          };
          ```
        '';
      };
      socketPath = lib.mkOption {
        type = lib.types.str;
        default = "${runtimeDir}/serve.sock";
        description = ''
          Absolute path of the dedicated Serve socket, always created with mode
          `0600`. The default follows the module's `/run/rex` runtime directory.
          Rex checks the forwarding process's user ID against the owner of
          tailscaled's LocalAPI socket before reading forwarded identities.
        '';
      };
    };

    extraListen = lib.mkOption {
      type = lib.types.listOf lib.types.str;
      default = [];
      example = ["127.0.0.1:7297"];
      description = ''
        Additional endpoints on which the same Rex server accepts connections.
        An entry may be an absolute Unix socket path, a `unix:///` URL, a TCP
        `host:port` address, or an `http://` URL without a path prefix.

        Use `tailnet://IP:port` for a listener identified by the host's tailscaled.
        An empty IP, as in `tailnet://:7297`, binds every host tailnet address.
        IPv6 addresses need brackets. Use `tailnet-serve:///absolute/path` for
        a Unix socket receiving requests from Tailscale Serve. Both schemes
        require `services.tailscale.enable`. Serve provides HTTPS for clients.

        When `tailscaleServe.enable` is true, a `tailnet://` address must use a
        different port than `tailscaleServe.httpsPort`. Serve takes that port
        for all tailnet traffic to the host, so a listener on it would never
        receive a connection, and evaluation fails. For example, this serves
        people over HTTPS through Serve on port 7297, and tagged machines,
        whose identity Serve does not forward, over a direct listener on 7298:

        ```nix
        services.rex = {
          tailscaleServe.enable = true;
          tailnetAllowIdentified = true;
          extraListen = ["tailnet://:7298"];
        };
        ```

        Only ordinary Unix listeners permit local API methods. Plain TCP and
        Tailscale listeners are remote, including loopback and Serve sockets. The primary endpoint,
        selected by `socketPath` or by `listenAddress` and `port`, remains the
        address used for discovery and process management. Startup fails if
        any configured endpoint cannot bind.

        This option does not open firewall ports. Configure any firewall rules
        for additional listeners through `networking.firewall`.
      '';
    };

    webSocketOriginPatterns = lib.mkOption {
      type = lib.types.listOf lib.types.str;
      default = [];
      example = [
        "https://rex.example.com"
        "https://*.example.net"
      ];
      description = ''
        Additional browser origins allowed to open WebSocket connections. Rex
        always allows the request host. Each entry is a case-insensitive,
        shell-style pattern interpreted by Go's `path.Match`. Patterns normally
        match the origin host. An entry that includes `://` matches the scheme
        and host together.

        Keep these patterns narrow. A broad pattern can allow another site to
        make cross-origin requests to Rex from a user's browser.
      '';
    };

    blockDirs = lib.mkOption {
      type = lib.types.listOf lib.types.str;
      default = [];
      example = ["/opt/rex/blocks"];
      description = ''
        The directories that Rex searches, in order, for executable block
        plugins. An empty list uses the default search path. A non-empty list
        replaces it.
      '';
    };

    reloadBlockPlugins = lib.mkOption {
      type = lib.types.bool;
      default = false;
      description = ''
        Whether to watch block plugin sources and restart a plugin process when
        its source changes. Rex itself remains running during the restart.
      '';
    };

    logFormat = lib.mkOption {
      type = lib.types.enum [
        "text"
        "json"
      ];
      default = "text";
      description = ''
        The format of each Rex message sent to the systemd journal. This option
        changes the message contents, not where systemd stores or rotates logs.
      '';
    };

    tailscale = {
      enable = lib.mkEnableOption "the embedded Tailscale listener";

      hostname = lib.mkOption {
        type = lib.types.str;
        default = "rex";
        example = "rex-server";
        description = ''
          The device name of the embedded Tailscale node. Node state is stored
          by device name. Changing this value creates a new node identity that
          must be enrolled separately.
        '';
      };

      controlUrl = lib.mkOption {
        type = lib.types.nullOr lib.types.str;
        default = null;
        example = "https://headscale.example.com";
        description = ''
          The coordination server the embedded node registers with, such as a
          self-hosted Headscale server. Null uses Tailscale's own control
          plane. Each control server keeps its own node identity under
          `/var/lib/rex/tsnet`, so changing this value enrolls a new node.

          Rex serves the tailnet only over HTTPS with certificates issued by
          the control server, which Headscale does not provide yet.
        '';
      };

      allowTailnetMembers = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = ''
          Whether every tailnet member permitted by the Tailscale access policy
          may connect. When false, Rex also requires the caller to belong to the
          Tailscale account that enrolled this node. A node enrolled with
          `advertiseTags` has no such account, so tags require this option.
          This option requires `tailscale.enable` to be true.
        '';
      };

      authKeyFile = lib.mkOption {
        type = lib.types.nullOr (lib.types.either lib.types.path lib.types.str);
        default = null;
        example = "/run/secrets/rex-tailscale-auth-key";
        description = ''
          A file containing a one-time Tailscale auth key used to enroll the
          embedded node without the interactive login flow. The file is exposed
          to the service through a systemd credential, so its path never needs
          to be readable by other users. The key is used only for the node's
          first enrollment: the enrolled identity persists under
          `/var/lib/rex/tsnet/<hostname>`, and later starts ignore the key.
          Point this at a file managed by a secrets tool rather than a Nix
          store path, because store paths are world-readable. This option
          requires `tailscale.enable` to be true.
        '';
      };

      advertiseTags = lib.mkOption {
        type = lib.types.listOf (lib.types.strMatching "tag:[A-Za-z][A-Za-z0-9-]*");
        default = [];
        example = ["tag:rex"];
        description = ''
          The Tailscale ACL tags the embedded node requests when it enrolls.
          Each entry has the form `tag:name`. Tags give the node a machine
          identity for the tailnet's access rules. They apply only at the
          node's first enrollment: the enrolled identity keeps them, and later
          starts ignore this option. The auth key or OAuth client used to
          enroll must be allowed to grant every listed tag.

          A tagged node has no owner, so the owner check that
          `allowTailnetMembers = false` performs would admit nobody. This
          option therefore requires `tailscale.allowTailnetMembers = true` as
          well as `tailscale.enable`.
        '';
      };
    };

    extraArgs = lib.mkOption {
      type = lib.types.listOf lib.types.str;
      default = [];
      example = ["--verbose"];
      description = ''
        Additional arguments passed to `rex server run`. Use this option only for
        flags that do not have a dedicated module option. Configuration fails
        if an entry tries to set a module-managed flag.
      '';
    };

    environment = lib.mkOption {
      type = lib.types.attrsOf lib.types.str;
      default = {};
      description = ''
        Additional environment variables for the Rex service. These values
        override variables set by the module when names overlap. The module
        sets `REX_CGROUP_DELEGATED` to `1`, which gives each terminal a cgroup
        of its own. This turns the cgroups off:

        ```nix
        services.rex.environment.REX_CGROUP_DELEGATED = "0";
        ```
      '';
    };

    openFirewall = lib.mkOption {
      type = lib.types.bool;
      default = false;
      description = ''
        Whether to open the primary listener's `port` in the NixOS firewall.
        This requires `socketPath` to be null. It does not open ports from
        `extraListen`. The embedded Tailscale listener does not need a host
        firewall rule.
      '';
    };

    openFirewallInterfaces = lib.mkOption {
      type = lib.types.listOf lib.types.str;
      default = [];
      example = ["tailscale0"];
      description = ''
        The network interfaces on which to open `port`. An empty list opens the
        port on every interface. This option is used only when `openFirewall`
        is true.
      '';
    };
  };

  config = lib.mkMerge [
    {
      # These are outside the mkIf blocks below, which would otherwise skip
      # them in exactly the configurations they are meant to reject.
      assertions = [
        {
          assertion = cfg.socketActivation -> cfg.enable;
          message = "services.rex.socketActivation requires services.rex.enable = true.";
        }
        {
          assertion = loginCfg.socketActivation -> loginCfg.enable;
          message = "services.rex.loginServer.socketActivation requires services.rex.loginServer.enable = true.";
        }
      ];
    }
    (lib.mkIf (cfg.enable || loginCfg.enable) {
      environment.systemPackages = lib.optional cfg.installClient cfg.package;

      # The ssh guard, for every account on this machine. ssh sends the local
      # TERM to the remote host, which will not have Rex's entry, so the guard
      # makes ssh announce xterm-256color instead, to every host. It defers to
      # an account that has run `rex terminfo setup`, whose own guard in
      # ~/.config/rex/ssh_config lets the hosts the account records through.
      # Outside a Rex terminal the block's first comparison fails and it does
      # nothing.
      #
      # The .deb and .rpm drop this file in /etc/ssh/ssh_config.d. NixOS
      # generates /etc/ssh/ssh_config itself and never includes that directory,
      # so the path is named here instead. Including the package's copy rather
      # than repeating the text keeps a single copy of the guard in the
      # repository, the one internal/sshconfig generates.
      #
      # extraConfig is placed at the top of the generated file, before the
      # "Host *" section, which is where a Match block has to be. mkAfter puts
      # Rex last among the extraConfig definitions, so anything written by the
      # administrator is matched first. A person's own ~/.ssh/config comes
      # before either, because ssh reads it before /etc/ssh/ssh_config and
      # applies the first SetEnv it finds.
      programs.ssh.extraConfig = lib.mkAfter ''
        Include ${sshGuardFile}
      '';

      # Both modes own the same runtime directory and Serve mapping, and their
      # ownership and permissions differ. Switching modes must be explicit.
      assertions = [
        {
          assertion = !(cfg.enable && loginCfg.enable);
          message = "services.rex.enable and services.rex.loginServer.enable are mutually exclusive: both own /run/rex and the Tailscale Serve mapping. The login server serves every account named in its accounts file; declare users.users.<name> yourself for any service account you want it to reach.";
        }
      ];
    })
    (lib.mkIf cfg.enable {
      # Reject combinations that would be ignored or make the firewall settings
      # disagree with the listener Rex actually uses.
      assertions = [
        {
          assertion = cfg.socketPath == null || lib.hasPrefix "/" cfg.socketPath;
          message = "services.rex.socketPath must be an absolute path or null.";
        }
        {
          # systemd could hold a TCP port too, but the module would then have to
          # repeat Rex's address parsing to keep ListenStream= and --listen in
          # agreement. A Unix socket is the case socket activation is for.
          assertion = cfg.socketActivation -> cfg.socketPath != null;
          message = "services.rex.socketActivation requires a Unix socket: set services.rex.socketPath to an absolute path, not null.";
        }
        {
          assertion = cfg.openFirewall -> cfg.socketPath == null;
          message = "services.rex.openFirewall requires services.rex.socketPath = null.";
        }
        {
          assertion = hasTcpListener -> cfg.allowAnonymous;
          message = ''
            services.rex.allowAnonymous = true is required when the primary listener
            is TCP (services.rex.socketPath = null) or services.rex.extraListen
            contains a plain TCP endpoint (host:port or http://). These callers
            are admitted anonymously with full access to the server.
          '';
        }
        {
          assertion = cfg.tailscaleServe.enable -> config.services.tailscale.enable;
          message = "services.rex.tailscaleServe.enable requires services.tailscale.enable = true.";
        }
        {
          assertion = lib.any isTailnetEndpoint cfg.extraListen -> config.services.tailscale.enable;
          message = "services.rex.extraListen tailnet schemes require services.tailscale.enable = true.";
        }
        {
          assertion = servePortCollisions cfg.tailscaleServe cfg.extraListen == [];
          message =
            servePortCollisionMessage "services.rex" cfg.tailscaleServe
            (servePortCollisions cfg.tailscaleServe cfg.extraListen);
        }
        {
          assertion = managedExtraArgs == [];
          message = ''
            services.rex.extraArgs contains flags that have dedicated module
            options: ${lib.concatStringsSep ", " managedExtraArgs}
          '';
        }
        {
          assertion = cfg.tailscale.allowTailnetMembers -> cfg.tailscale.enable;
          message = ''
            services.rex.tailscale.allowTailnetMembers requires
            services.rex.tailscale.enable = true.
          '';
        }
        {
          assertion = cfg.tailscale.authKeyFile != null -> cfg.tailscale.enable;
          message = ''
            services.rex.tailscale.authKeyFile requires
            services.rex.tailscale.enable = true.
          '';
        }
        {
          assertion = cfg.tailscale.advertiseTags != [] -> cfg.tailscale.enable;
          message = ''
            services.rex.tailscale.advertiseTags requires
            services.rex.tailscale.enable = true.
          '';
        }
        {
          assertion = cfg.tailscale.advertiseTags != [] -> cfg.tailscale.allowTailnetMembers;
          message = ''
            services.rex.tailscale.advertiseTags requires
            services.rex.tailscale.allowTailnetMembers = true. A tagged node has
            no owner, so owner-only access would admit nobody.
          '';
        }
      ];

      # Create the default service identity so `services.rex.enable = true` is a
      # complete configuration. Custom user and group names refer to accounts
      # managed elsewhere in the NixOS configuration.
      users.groups = lib.mkIf (cfg.group == "rex") {
        rex = {};
      };

      users.users = lib.mkIf (cfg.user == "rex") {
        rex = {
          isSystemUser = true;
          group = cfg.group;
          home = "/var/lib/rex";
          createHome = true;
        };
      };

      systemd.services.rex = {
        description = "Rex Server";
        documentation = ["https://superlogical.com"];
        # With socket activation, rex.socket starts this unit on the first
        # connection, so nothing starts it at boot.
        wantedBy = lib.optional (!cfg.socketActivation) "multi-user.target";
        wants = ["network-online.target"];
        # The packaged rex.service does not depend on rex.socket, but this unit
        # must, because the dependency is what changes this unit's file when
        # socketActivation changes. wantedBy alone does not: NixOS keeps it in
        # symlinks, not in the file. `nixos-rebuild switch` acts only on units
        # whose file changed, and a running server left alone breaks both ways.
        # Turning activation off stops rex.socket, whose RemoveOnStop deletes
        # the socket under the server. Turning it on cannot start rex.socket,
        # because systemd refuses to listen for a service that already runs.
        # With the file changed, the switch restarts the server instead.
        #
        # Requires= also means `systemctl stop rex.socket` alone stops the
        # server, instead of leaving it running with no socket file.
        after =
          ["network-online.target"]
          ++ lib.optional hasHostTailnetListener "tailscaled.service"
          ++ lib.optional cfg.socketActivation "rex.socket";
        requires =
          lib.optional hasHostTailnetListener "tailscaled.service"
          ++ lib.optional cfg.socketActivation "rex.socket";
        # The login server leaves /run/rex behind when it stops, so that the
        # per-account servers it started keep working. Without logind, those
        # servers keep their sockets under /run/rex/accounts. Starting this unit
        # would give everything in /run/rex to the service user and cut those
        # servers off. systemd changes the ownership before ExecStartPre could
        # intervene, so the check must be an assertion. Once nobody uses the
        # login server's sessions, remove /run/rex or reboot.
        unitConfig.AssertPathExists = "!${runtimeDir}/accounts";
        # Select the systemd-managed directory explicitly: Rex otherwise appends
        # /rex to XDG_RUNTIME_DIR, placing coordination files under /run/rex/rex.
        # The service does not inherit environment.sessionVariables, and child
        # Rex clients should discover the same default socket as the service.
        environment =
          {
            # systemd derives HOME from User's account. An explicit environment.HOME
            # still overrides it without relocating Rex's persistent state.
            XDG_RUNTIME_DIR = runtimeDir;
            REX_RUNTIME_DIR = runtimeDir;
            TERMINFO_DIRS = terminfoDirs;
            # Tells the server that the unit sets Delegate below, so the server
            # may give each terminal a cgroup of its own. Never set it without
            # Delegate. packaging/systemd/rex.service explains why.
            REX_CGROUP_DELEGATED = "1";
          }
          // cfg.environment;
        serviceConfig = {
          # Rex starts terminal workloads on behalf of clients. Process and
          # filesystem restrictions here would also restrict those workloads, so
          # the service uses its configured user account as its isolation boundary.
          #
          # Rex tells systemd when it is ready for clients. Starting the unit
          # waits for that, and fails if the server cannot open its socket.
          Type = "notify";
          NotifyAccess = "main";
          User = cfg.user;
          Group = cfg.group;
          # Pass stable paths and module settings explicitly. This keeps service
          # behavior independent of CLI defaults that may change in later releases.
          ExecStart = lib.escapeShellArgs (
            [
              (lib.getExe cfg.package)
              "server"
              "run"
              "--listen"
              listenEndpoint
              "--state-dir"
              stateDir
              "--socket-mode"
              cfg.socketMode
            ]
            ++ lib.optional cfg.allowAnonymous "--allow-anonymous"
            ++ lib.optional cfg.tailnetAllowIdentified "--tailnet-allow-identified"
            ++ lib.optionals (cfg.tailscaledSocket != null) [
              "--tailscaled-socket"
              (toString cfg.tailscaledSocket)
            ]
            ++ lib.concatMap (endpoint: ["--extra-listen" endpoint]) extraListen
            ++ lib.concatMap (pattern: ["--websocket-origin-pattern" pattern])
            cfg.webSocketOriginPatterns
            ++ lib.concatMap (dir: ["--block-dir" dir]) cfg.blockDirs
            ++ lib.optional cfg.reloadBlockPlugins "--block-plugin-reload"
            ++ [
              "--log-format"
              cfg.logFormat
            ]
            ++ lib.optionals cfg.tailscale.enable [
              "--tailscale"
              "--tailscale-hostname"
              cfg.tailscale.hostname
            ]
            ++ lib.optionals (cfg.tailscale.controlUrl != null) [
              "--tailscale-control-url"
              cfg.tailscale.controlUrl
            ]
            ++ lib.optional cfg.tailscale.allowTailnetMembers
            "--tailscale-allow-tailnet-members"
            ++ lib.optionals (cfg.tailscale.authKeyFile != null) [
              "--tailscale-auth-key-file"
              "%d/${tailscaleAuthKeyCredential}"
            ]
            ++ tailscaleAdvertiseTagArgs
            ++ cfg.extraArgs
          );
          LoadCredential =
            lib.mkIf (cfg.tailscale.authKeyFile != null)
            ["${tailscaleAuthKeyCredential}:${cfg.tailscale.authKeyFile}"];
          # Send service logs explicitly to journald. Journald owns rotation and
          # retention on NixOS. Rex manages files only for detached CLI servers.
          StandardOutput = "journal";
          StandardError = "journal";
          Restart = "on-failure";
          RestartSec = "5s";
          # Stopping the service sends SIGTERM to the server alone. The server
          # saves every session and then closes its terminals, and systemd sends
          # SIGKILL to anything left once the server exits. The default,
          # control-group, would also send SIGTERM to every program in the
          # server's terminals. Shells such as fish exit on it, and their windows
          # would not be saved. packaging/systemd/rex.service explains this
          # setting at more length.
          KillMode = "mixed";
          # A program that the kernel kills for using too much memory must not
          # stop the whole unit and close every other terminal.
          # packaging/systemd/rex.service explains this setting at more length.
          OOMPolicy = "continue";
          # Hand the unit's cgroup to the server. It runs itself in server/
          # and each terminal in a cgroup of its own, so systemd-oomd can kill
          # one terminal instead of the whole service. systemd before 254 ignores
          # DelegateSubgroup, and the server then moves itself into server/.
          # packaging/systemd/rex.service explains both settings at more length.
          Delegate = true;
          DelegateSubgroup = "server";
          # StateDirectory creates /var/lib/rex for persistent data.
          # RuntimeDirectory creates /run/rex for the socket and coordination files.
          StateDirectory = "rex";
          StateDirectoryMode = "0700";
          RuntimeDirectory = "rex";
          RuntimeDirectoryMode = "0750";
          # Keep /run/rex when this unit stops. systemd would otherwise delete it,
          # and with rex.socket active that removes the socket systemd is still
          # waiting on, so the next client finds nothing to connect to. Without
          # rex.socket, keeping the directory is harmless: the server removes its
          # own socket when it stops, and the next start reuses the directory.
          RuntimeDirectoryPreserve = "yes";
          # Exclude other local users from newly created files, including those
          # created by workloads. Rex explicitly applies socketMode to its sockets,
          # so their final permissions do not depend on this umask.
          UMask = "0007";
        };
      };

      # The packaged rex.socket is the model for this unit, and its comments
      # explain each setting at more length.
      systemd.sockets.rex = lib.mkIf cfg.socketActivation {
        description = "Rex Server Socket";
        documentation = ["https://superlogical.com"];
        wantedBy = ["sockets.target"];
        # A connection would start rex.service, and the login server's units set
        # up /run/rex differently. The assertion above already keeps both modes
        # out of one generation, so these lines only repeat the packaged unit.
        conflicts = ["rex-login-server.service" "rex-login-server.socket"];
        before = ["rex-login-server.service"];
        # The same check as rex.service: do not take /run/rex from the account
        # servers a login server left behind.
        unitConfig.AssertPathExists = "!${runtimeDir}/accounts";
        # The server adopts only sockets whose path matches an endpoint on its
        # command line, so every path here must also be a --listen or
        # --extra-listen in rex.service. Both come from the same options.
        #
        # The Serve socket shares SocketMode= with the primary socket, so the
        # group can connect to it, where the server alone would create it with
        # mode 0600. That grants nothing: the tailnet-serve:// listener checks
        # each connection's peer UID against tailscaled's and refuses any other
        # caller.
        listenStreams =
          [cfg.socketPath]
          ++ lib.optional cfg.tailscaleServe.enable cfg.tailscaleServe.socketPath;
        socketConfig = {
          SocketUser = cfg.user;
          SocketGroup = cfg.group;
          SocketMode = cfg.socketMode;
          # systemd creates the socket before rex.service has ever run, so
          # /run/rex has to exist first, with the owner and mode rex.service
          # gives it. systemd prepares the directory only when the unit runs a
          # command, so ExecStartPre runs one that does nothing. User and Group
          # apply to that command and set the directory's owner. Preserve keeps
          # systemd from deleting /run/rex, and the socket in it, from under a
          # running server when this unit stops.
          #
          # Fixing the owner with `install -d` instead is not enough: after the
          # login server has used /run/rex, files inside it stay owned by root
          # and the server fails to start. RuntimeDirectory hands them all back.
          RuntimeDirectory = "rex";
          RuntimeDirectoryMode = "0750";
          RuntimeDirectoryPreserve = "yes";
          User = cfg.user;
          Group = cfg.group;
          ExecStartPre = "${pkgs.coreutils}/bin/true";
          # The server never removes a socket systemd created. Without this, the
          # file would outlive both units and clients would find a socket that
          # nobody answers, then fail with "permission denied" replacing it.
          RemoveOnStop = true;
        };
      };

      systemd.services.rex-tailscale-serve =
        lib.mkIf cfg.tailscaleServe.enable
        (tailscaleServeService {
          inherit (cfg.tailscaleServe) httpsPort socketPath;
          unit =
            if cfg.socketActivation
            then "rex.socket"
            else "rex.service";
        });

      # Leave the firewall unchanged unless explicitly requested. Interface rules
      # can limit the TCP listener to a specific network on hosts with more than
      # one network connection.
      networking.firewall = lib.mkIf cfg.openFirewall firewallConfig;
    })
    (lib.mkIf loginCfg.enable {
      assertions =
        [
          {
            assertion = loginCfg.accounts != {} || loginCfg.accountsFile != null;
            message = "services.rex.loginServer requires non-empty accounts or accountsFile: an empty map admits nobody.";
          }
          {
            assertion = loginCfg.accountsFile != null -> (loginCfg.accounts == {} && loginCfg.defaults == {});
            message = "services.rex.loginServer.accountsFile requires services.rex.loginServer.accounts and services.rex.loginServer.defaults to be empty.";
          }
          {
            assertion = loginCfg.tailscaleServe.enable -> config.services.tailscale.enable;
            message = "services.rex.loginServer.tailscaleServe.enable requires services.tailscale.enable = true.";
          }
          {
            assertion = lib.any isTailnetEndpoint loginCfg.extraListen -> config.services.tailscale.enable;
            message = "services.rex.loginServer.extraListen tailnet schemes require services.tailscale.enable = true.";
          }
          {
            assertion = servePortCollisions loginCfg.tailscaleServe loginCfg.extraListen == [];
            message =
              servePortCollisionMessage "services.rex.loginServer" loginCfg.tailscaleServe
              (servePortCollisions loginCfg.tailscaleServe loginCfg.extraListen);
          }
          {
            assertion =
              lib.any (endpoint: !isUnixEndpoint endpoint && !isTailnetEndpoint endpoint)
              loginCfg.extraListen
              -> loginCfg.allowAnonymous;
            message = "services.rex.loginServer.allowAnonymous = true is required when services.rex.loginServer.extraListen contains a plain TCP endpoint (host:port or http://). These callers can reach only accounts listed under anonymous.";
          }
          {
            assertion = managedLoginServerExtraArgs == [];
            message = ''
              services.rex.loginServer.extraArgs contains flags that have dedicated module
              options: ${lib.concatStringsSep ", " managedLoginServerExtraArgs}
            '';
          }
        ]
        ++ lib.mapAttrsToList (key: account: {
          # A default chooses a named account; it cannot choose the wildcard.
          # Let Rex validate external files, which may not exist at evaluation.
          assertion =
            loginCfg.accountsFile
            == null
            -> (account != "*" && builtins.hasAttr account loginCfg.accounts);
          message = "services.rex.loginServer.defaults.${builtins.toJSON key} must name an entry in services.rex.loginServer.accounts and must not be \"*\" (got ${builtins.toJSON account}).";
        })
        loginCfg.defaults;

      environment.etc."rex/accounts.jsonc" = lib.mkIf (loginCfg.accountsFile == null) {
        # JSON is valid HuJSON. The loader requires version 1 even when the
        # accounts and defaults are otherwise valid. Logins are not secrets.
        text = builtins.toJSON ({
            version = 1;
            accounts = lib.mapAttrs (_: a: {inherit (a) principals;}) loginCfg.accounts;
          }
          // lib.optionalAttrs (loginCfg.defaults != {}) {inherit (loginCfg) defaults;});
        mode = "0644";
      };

      # Rex proves identity before PAM runs. The auth stack ends in pam_deny,
      # which makes pam_setcred fail; the helper tolerates that like sshd after
      # public-key authentication. pam_env comes from the module default, and
      # pam_limits appears when security.pam.loginLimits or this service's limits
      # is non-empty, as the PAM module already arranges.
      security.pam.services.rex-login-server = lib.mkIf loginCfg.pam {
        unixAuth = false;
        allowNullPassword = false;
        startSession = true;
      };

      systemd.services.rex-login-server = {
        description = "Rex Login Server";
        documentation = ["https://superlogical.com"];
        # With socket activation, rex-login-server.socket starts this unit on
        # the first connection, so nothing starts it at boot.
        wantedBy = lib.optional (!loginCfg.socketActivation) "multi-user.target";
        wants = ["network-online.target"];
        # The dependency on the socket unit is for `nixos-rebuild switch`, as
        # on rex.service, which explains it.
        after =
          ["network-online.target"]
          ++ lib.optional loginServerHasHostTailnetListener "tailscaled.service"
          ++ lib.optional loginCfg.socketActivation "rex-login-server.socket";
        requires =
          lib.optional loginServerHasHostTailnetListener "tailscaled.service"
          ++ lib.optional loginCfg.socketActivation "rex-login-server.socket";
        environment = {
          REX_RUNTIME_DIR = runtimeDir;
          TERMINFO_DIRS = terminfoDirs;
        };
        # The /etc path is stable across generations. Track the generated source
        # so accounts and defaults changes both activate the replacement policy.
        reloadTriggers =
          lib.optional (loginCfg.accountsFile == null)
          config.environment.etc."rex/accounts.jsonc".source;
        serviceConfig = {
          # No User or Group: session helpers need root to open PAM sessions
          # before launching servers with each account's credentials and home.
          Type = "notify-reload";
          NotifyAccess = "main";
          ExecStart = lib.escapeShellArgs (
            [
              (lib.getExe cfg.package)
              "login-server"
              "--listen"
              "unix://${loginServerSocketPath}"
              "--accounts"
              loginServerAccountsFile
              "--runtime-root"
              runtimeDir
              "--log-format"
              cfg.logFormat
            ]
            ++ lib.optionals (cfg.tailscaledSocket != null) [
              "--tailscaled-socket"
              (toString cfg.tailscaledSocket)
            ]
            ++ lib.optional (!loginCfg.pam) "--pam=false"
            ++ lib.optional loginCfg.allowAnonymous "--allow-anonymous"
            ++ lib.concatMap (endpoint: ["--extra-listen" endpoint]) loginServerExtraListen
            ++ loginCfg.extraArgs
          );
          StandardOutput = "journal";
          StandardError = "journal";
          Restart = "on-failure";
          RestartSec = "5s";
          RuntimeDirectory = "rex";
          # Without logind, accounts traverse /run/rex to reach their 0700 directories.
          # The login server and Serve sockets remain root-owned with mode 0600.
          RuntimeDirectoryMode = "0755";
          # Session helpers must outlive login server stops and restarts.
          # pam_systemd moves them into session scopes on logind hosts;
          # KillMode=process also preserves helpers on hosts without logind.
          # Keep /run/rex so surviving fallback sockets remain discoverable.
          KillMode = "process";
          # On hosts without logind, account servers run in this unit. A program
          # that the kernel kills for using too much memory in one of them must
          # not stop and restart the login server.
          # packaging/systemd/rex-login-server.service explains this setting at
          # more length.
          OOMPolicy = "continue";
          # No Delegate and no REX_CGROUP_DELEGATED, unlike services.rex.
          # Account servers would inherit the variable without having a
          # delegated cgroup. packaging/systemd/rex-login-server.service
          # explains why.
          RuntimeDirectoryPreserve = "yes";
          # No StateDirectory: account servers manage their own state.
        };
      };

      # The packaged rex-login-server.socket is the model for this unit, and
      # its comments explain each setting at more length.
      systemd.sockets.rex-login-server = lib.mkIf loginCfg.socketActivation {
        description = "Rex Login Server Socket";
        documentation = ["https://superlogical.com"];
        wantedBy = ["sockets.target"];
        # As on rex.socket, the module never puts both modes in one generation,
        # so these lines only repeat the packaged unit. There, Before= is what
        # makes systemd finish stopping rex.service before this unit gives
        # /run/rex to root. It is not After= because systemd starts every
        # socket before any regular service.
        conflicts = ["rex.service" "rex.socket"];
        before = ["rex.service"];
        # Every path here must also be a --listen or --extra-listen of the
        # login server, which adopts only sockets it is configured to serve.
        # SocketMode applies to both, and 0600 is what the login server gives
        # each of them itself. tailscaled runs as root, so Serve still connects.
        listenStreams =
          [loginServerSocketPath]
          ++ lib.optional loginCfg.tailscaleServe.enable loginCfg.tailscaleServe.socketPath;
        socketConfig = {
          SocketMode = "0600";
          # Set /run/rex up as rex-login-server.service does, owned by root, and
          # hand back anything rex.service left in it. ExecStartPre makes
          # systemd prepare the directory, and Preserve keeps it, and the
          # account servers' sockets under it, when this unit stops.
          RuntimeDirectory = "rex";
          RuntimeDirectoryMode = "0755";
          RuntimeDirectoryPreserve = "yes";
          ExecStartPre = "${pkgs.coreutils}/bin/true";
          # The login server never removes a socket systemd created, so remove
          # it here once this unit stops.
          RemoveOnStop = true;
        };
      };

      systemd.services.rex-tailscale-serve =
        lib.mkIf loginCfg.tailscaleServe.enable
        (tailscaleServeService {
          inherit (loginCfg.tailscaleServe) httpsPort socketPath;
          unit =
            if loginCfg.socketActivation
            then "rex-login-server.socket"
            else "rex-login-server.service";
        });
    })
  ];
}
