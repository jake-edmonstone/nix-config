#!/usr/bin/env bash
# Point this flake at a Rex release on a channel.
#
#   ./update.sh                    # the latest snapshot
#   ./update.sh stable             # the latest stable release
#   ./update.sh stable <commit>    # the stable release built from one commit
#
# The channel is snapshot, preview, or stable, and defaults to snapshot.
#
# The commit is optional and is written in full, as 40 lowercase hex digits. Without it the
# script asks for the channel's latest release. With it the script asks for the release of
# that one commit, and stops if the channel has no release for it.
#
# The release workflows always pass the commit they are publishing. The latest release is
# cached for a minute, so a read right after a publication can still answer with the release
# before it. The release of one commit never changes, so it is never answered from an old
# copy.
#
# The script changes two files:
#
# - sources.json gets the release's version, commit, and, for each Nix system (see the list
#   below), the download URL and checksum. The flake reads everything about the release from here, so updating never
#   touches Nix code. `nix build` rejects any download that does not match its checksum.
# - flake.nix gets the channel in its description, which `nix flake metadata` shows. Nix
#   requires the description to be a plain string, not something read from sources.json, so
#   the script writes the channel into it. This is the only line of Nix it changes.
#
# Requires curl, jq, and sed.
set -euo pipefail

channel="${1:-snapshot}"
commit="${2:-}"
api="https://blob.superlogical.com/api/releases/rex/${channel}"
cd "$(dirname "$0")"

# The API answers anything but a full lowercase commit with 404, the same as a commit it has
# no release for. Checking the spelling here tells the two apart, so an abbreviated commit
# gets a useful message instead of "no release".
if [[ -n "$commit" ]]; then
  [[ "$commit" =~ ^[0-9a-f]{40}$ ]] || {
    echo "the commit must be 40 lowercase hex digits, not ${commit}" >&2
    exit 1
  }
  api="${api}?commit=${commit}"
fi

# curl's own message for a 404 is the status code and nothing else, so say what was missing.
release=$(curl -fsSL --proto '=https' "$api") || {
  if [[ -n "$commit" ]]; then
    echo "the ${channel} channel has no release for ${commit}" >&2
  else
    echo "could not read the latest ${channel} release from ${api}" >&2
  fi
  exit 1
}

# Pick one release archive for each Nix system. Each archive holds just the rex binary.
#
#   x86_64-linux     rex-linux-amd64.tar.gz
#   aarch64-linux    rex-linux-arm64.tar.gz
#   aarch64-darwin   rex-darwin-arm64.zip
#
# macOS releases only come as a zip. Old snapshots, published before the Linux tarball
# existed, also only have a zip, so a missing tarball falls back to the zip of the same name.
#
# The script matches the whole file name, not just the os and arch fields. The musl builds
# have the same os and arch as the glibc builds, so rex-linux-amd64-musl.tar.gz would
# otherwise also match x86_64-linux.
jq --arg channel "$channel" '
  def pick($os; $arch):
    [.artifacts[] | select(.os == $os and .arch == $arch)] as $a
    | ($a | map(select(.filename == "rex-\($os)-\($arch).tar.gz")))
      + ($a | map(select(.filename == "rex-\($os)-\($arch).zip")))
    | if length == 0 then error("no \($os) \($arch) archive on the \($channel) channel")
      else .[0] end
    | {url: .downloadUrl, sha256: .sha256};
  {
    channel: $channel,
    version: .version,
    commit: .commit,
    systems: {
      "x86_64-linux": pick("linux"; "amd64"),
      "aarch64-linux": pick("linux"; "arm64"),
      "aarch64-darwin": pick("darwin"; "arm64")
    }
  }' <<<"$release" >sources.json.new
mv sources.json.new sources.json

sed "s/^  description = .*/  description = \"Rex, the multiplexer for all work (prebuilt, ${channel} channel)\";/" \
  flake.nix >flake.nix.new
grep -q "(prebuilt, ${channel} channel)" flake.nix.new || {
  echo "flake.nix has no description line to update" >&2
  exit 1
}
mv flake.nix.new flake.nix

jq -r '"rex \(.version) (\(.commit))", (.systems | to_entries[] | "  \(.key): \(.value.url)")' \
  sources.json
