{
  # Prebuilt Rex for Nix, NixOS, and nix-darwin.
  #
  # This flake packages the published Rex release binary. It does not build Rex from source,
  # so it works without access to the Rex source code. It has a package for each of these
  # systems:
  #
  #   x86_64-linux     Linux on Intel and AMD
  #   aarch64-linux    Linux on ARM
  #   aarch64-darwin   macOS on Apple silicon
  #
  # It also has two modules that install and configure that package for you:
  #
  #   nixosModules.default         runs the Rex server as a system service, on NixOS only
  #   homeManagerModules.default   sets up Rex for your own account, wherever home-manager
  #                                runs, such as Fedora or Amazon Linux with Nix installed,
  #                                or macOS
  #
  # nix-darwin has no Rex module. On a Mac, use the home-manager module or install the
  # package, as shown below.
  #
  # Each release channel has its own URL. Pick one:
  #
  #   https://pkgs.superlogical.com/rex/nix/stable.tar.gz     tested releases
  #   https://pkgs.superlogical.com/rex/nix/preview.tar.gz    previews of the next release
  #   https://pkgs.superlogical.com/rex/nix/snapshot.tar.gz   a build of every change
  #
  # Try Rex without installing it:
  #
  #   nix run https://pkgs.superlogical.com/rex/nix/stable.tar.gz -- --help
  #
  # Install it in your user profile, on Linux or macOS:
  #
  #   nix profile add https://pkgs.superlogical.com/rex/nix/stable.tar.gz
  #
  # Older versions of Nix call that command `nix profile install`.
  #
  # Run the Rex server on NixOS by adding the flake to your system configuration:
  #
  #   {
  #     inputs.rex.url = "https://pkgs.superlogical.com/rex/nix/stable.tar.gz";
  #
  #     outputs = { nixpkgs, rex, ... }: {
  #       nixosConfigurations.myhost = nixpkgs.lib.nixosSystem {
  #         system = "x86_64-linux";
  #         modules = [
  #           rex.nixosModules.default
  #           { services.rex.enable = true; }
  #         ];
  #       };
  #     };
  #   }
  #
  # Set up Rex for your own account on a Linux machine that NixOS doesn't manage, such as
  # Fedora with Nix installed, by adding the flake to your home-manager configuration:
  #
  #   {
  #     inputs.rex.url = "https://pkgs.superlogical.com/rex/nix/stable.tar.gz";
  #
  #     outputs = { home-manager, nixpkgs, rex, ... }: {
  #       homeConfigurations.alice = home-manager.lib.homeManagerConfiguration {
  #         pkgs = nixpkgs.legacyPackages.x86_64-linux;
  #         modules = [
  #           rex.homeManagerModules.default
  #           {
  #             home.username = "alice";
  #             home.homeDirectory = "/home/alice";
  #             home.stateVersion = "26.05";
  #
  #             # Install the rex command and set up your account to use it.
  #             programs.rex.enable = true;
  #
  #             # Run your personal Rex server. Linux only.
  #             services.rex.enable = true;
  #
  #             # home-manager writes ~/.ssh/config only when this is on, and
  #             # programs.rex adds the ssh guard to it.
  #             programs.ssh.enable = true;
  #           }
  #         ];
  #       };
  #     };
  #   }
  #
  # The module has two parts:
  #
  # - programs.rex installs the rex command. It also writes Rex's terminfo entry to
  #   ~/.terminfo, which tells programs such as vim and less what a Rex terminal can do. And it
  #   adds Rex's ssh guard to ~/.ssh/config, which stops ssh from passing Rex's terminal type
  #   to machines that wouldn't recognize it.
  # - services.rex keeps your personal Rex server running as a systemd user service, under
  #   your own account. It starts when you log in and stops when you log out. To start it at
  #   boot and keep it running while you are logged out, run this once:
  #
  #     loginctl enable-linger
  #
  # On a Mac, the Rex app runs the server, so turn on programs.rex and leave services.rex
  # off. The module is also available as rex.homeModules.default, the name some home-manager
  # setups expect.
  #
  # Install Rex on a Mac managed by nix-darwin by adding the package to your system
  # configuration:
  #
  #   {
  #     inputs.rex.url = "https://pkgs.superlogical.com/rex/nix/stable.tar.gz";
  #
  #     outputs = { nix-darwin, rex, ... }: {
  #       darwinConfigurations.mymac = nix-darwin.lib.darwinSystem {
  #         modules = [
  #           {
  #             nixpkgs.hostPlatform = "aarch64-darwin";
  #             environment.systemPackages = [ rex.packages.aarch64-darwin.rex ];
  #           }
  #         ];
  #       };
  #     };
  #   }
  #
  # The channel URL always serves the newest release on that channel. Each release also has a
  # URL of its own that never changes, such as
  #
  #   https://pkgs.superlogical.com/rex/nix/stable/1.2.0.tar.gz
  #
  # and flake.lock records that URL, not the channel URL. The package host names it in a
  # `Link: rel="immutable"` header when Nix downloads the channel URL. Your lock therefore keeps
  # working, on any machine, after newer releases come out. To move to the newest release on
  # your channel, run:
  #
  #   nix flake update rex
  #
  # sources.json names the channel and release this copy of the flake installs, with the
  # download URL and checksum for each system. Those downloads come from
  # blob.superlogical.com.
  #
  # For maintainers: this flake lives in packaging/nix in the Rex repository. Every package
  # publication packs it into the tarball for its channel (see
  # .github/scripts/pack-flake.js). The packed copy's sources.json names the release that
  # publication made, and the nixos-module.nix, home-manager-module.nix, xterm-rex.bin, and
  # 50-rex.conf links are replaced by the files themselves.
  #
  # To point this directory at a channel's newest release, run ./update.sh with the channel.
  # It rewrites sources.json and the channel named in the description below. Nix only accepts
  # a plain string as the description, so the description cannot read sources.json itself.
  description = "Rex, the multiplexer for all work (prebuilt, preview channel)";

  inputs.nixpkgs.url = "https://channels.nixos.org/nixpkgs-unstable/nixexprs.tar.xz";

  outputs = {
    self,
    nixpkgs,
  }: let
    inherit (nixpkgs) lib;
    sources = builtins.fromJSON (builtins.readFile ./sources.json);
    systems = builtins.attrNames sources.systems;

    # Rex is proprietary, and nixpkgs refuses to build unfree packages unless told otherwise.
    # Choosing this flake is that choice, so allow Rex, and only Rex, here. Otherwise every
    # user would need NIXPKGS_ALLOW_UNFREE=1 and --impure on each command.
    pkgsFor = system:
      import nixpkgs {
        inherit system;
        config.allowUnfreePredicate = pkg: lib.getName pkg == "rex";
      };

    rexFor = pkgs: let
      source = sources.systems.${pkgs.stdenv.hostPlatform.system};
    in
      pkgs.stdenvNoCC.mkDerivation {
        pname = "rex";
        inherit (sources) version;

        src = pkgs.fetchurl {inherit (source) url sha256;};
        # The release archive keeps its files at the top level, with no enclosing directory.
        sourceRoot = ".";

        # On Linux, postInstall uses patchelf to rewrite two paths inside the binary so that it
        # runs on NixOS, which has no /lib or /usr/lib. The macOS binary needs no such change.
        # It only uses libraries that ship with macOS itself, such as /usr/lib/libSystem.B.dylib.
        #
        # The macOS binary must also stay exactly as released. macOS on Apple silicon only
        # runs signed programs, and the linker signed this one when it was built. Changing
        # any byte of the file breaks that signature, and macOS then stops the program as
        # soon as it starts.
        #
        # macOS releases, and snapshots published before the tarball existed, are only
        # available as a zip, which needs unzip to unpack.
        nativeBuildInputs =
          lib.optional pkgs.stdenv.hostPlatform.isLinux pkgs.patchelf
          ++ lib.optional (lib.hasSuffix ".zip" source.url) pkgs.unzip;

        # Keep the binary as released, apart from the two paths postInstall sets on Linux.
        # Stripping would also break the macOS signature.
        dontStrip = true;

        # Turn off the cleanup that Nix runs on every Linux binary after installing it. That
        # cleanup (patchelf --shrink-rpath) removes each library directory postInstall adds
        # unless the binary was linked against a library in it. Rex is never linked against
        # PAM. It opens libpam.so.0 by name when someone logs in (see
        # internal/pam/pam_dlopen.go), so the cleanup would remove the pam directory and the
        # login server would fail to find PAM.
        dontPatchELF = true;

        installPhase = ''
          runHook preInstall
          install -Dm755 rex "$out/bin/rex"

          # Rex's own terminfo entry, the database record that tells vim, htop, less and
          # tmux what a Rex terminal can do. A program that meets a TERM it cannot find in
          # the database refuses to run, so the entry has to be installed before anything
          # claims the name xterm-rex. The release archive holds only the binary, so the
          # entry travels with this flake: xterm-rex.bin is a link to the same compiled
          # file the binary embeds, and packing the flake replaces the link with the file.
          #
          # ncurses files an entry under the first character of its name on Linux, and
          # under that character's hexadecimal code on macOS, whose file systems do not
          # tell "x" and "X" apart. A Nix profile is read from both systems, so write both
          # layouts.
          for name in x/xterm-rex 78/xterm-rex r/rex 72/rex; do
            install -Dm644 ${./xterm-rex.bin} "$out/share/terminfo/$name"
          done

          # The ssh guard, the ssh_config block that stops TERM=xterm-rex from reaching
          # hosts that cannot resolve it. The .deb and .rpm drop that block in
          # /etc/ssh/ssh_config.d. NixOS generates /etc/ssh/ssh_config itself and never
          # reads that directory, so the Rex NixOS module includes this path from there
          # instead.
          #
          # Neither file does anything on its own. Both wait for a terminal to claim
          # xterm-rex, and a server claims it wherever it finds the entry installed and
          # the ssh guard in place, unless REX_TERM names another entry.
          install -Dm644 ${./50-rex.conf} "$out/share/rex/ssh_config.d/50-rex.conf"
          runHook postInstall
        '';

        postInstall = lib.optionalString pkgs.stdenv.hostPlatform.isLinux ''
          # Point the binary at the Nix store. A Linux binary records two paths that the
          # system uses to start it:
          #
          #   interpreter   the loader that starts the program and loads its libraries,
          #                 such as /lib64/ld-linux-x86-64.so.2
          #   rpath         the directories the loader searches for those libraries
          #
          # The usual paths do not exist on NixOS, so both must name directories in the
          # store. The rpath lists glibc, whose libraries Rex is linked against, and pam,
          # which Rex opens by name when someone logs in. Listing pam here also makes Nix
          # keep pam installed for as long as Rex is.
          #
          # Set the rpath first and the interpreter second, as two separate commands.
          # patchelf 0.19 damages the Rex binary when it sets the interpreter first, and a
          # single command with both flags does the same. The damaged binary crashes in the
          # loader before any Rex code runs (NixOS/patchelf#674). The autoPatchelfHook in
          # nixpkgs uses that order, which is why this flake runs patchelf itself. patchelf
          # 0.15 works with either order.
          #
          # To see both paths in a built package:
          #
          #   patchelf --print-interpreter result/bin/rex
          #   patchelf --print-rpath result/bin/rex
          bin=$out/bin/rex
          rpath=${lib.getLib pkgs.glibc}/lib:${lib.getLib pkgs.pam}/lib
          patchelf --set-rpath "$rpath" "$bin"
          patchelf --set-interpreter "$(cat ${pkgs.stdenv.cc}/nix-support/dynamic-linker)" "$bin"
        '';

        meta = {
          description = "The multiplexer for all work";
          homepage = "https://superlogical.com";
          license = lib.licenses.unfree;
          sourceProvenance = [lib.sourceTypes.binaryNativeCode];
          platforms = systems;
          mainProgram = "rex";
        };
      };
  in {
    packages = lib.genAttrs systems (system: rec {
      rex = rexFor (pkgsFor system);
      default = rex;
    });

    # The NixOS module for the Rex server, the same one the Rex source flake provides. Its
    # services.rex.package option defaults to this flake's rex package. See the module's
    # options for listeners, Tailscale, and the login server.
    nixosModules.default = import ./nixos-module.nix self;

    # The home-manager module, the same one the Rex source flake provides. Its
    # programs.rex.package and services.rex.package options default to this flake's rex
    # package.
    #
    # Flakes don't agree on a name for this output. Most flakes, and most READMEs people copy
    # from, use homeManagerModules. home-manager's own flake-parts module uses homeModules.
    # Both names point at the same module, so a configuration can use either one.
    #
    # This flake has no home-manager input, because the module never refers to home-manager
    # directly. It declares Rex's options and sets options that home-manager defines, and
    # those come from the user's own home-manager once their configuration imports the module.
    # An input here would add a home-manager entry to the flake.lock of every Rex user,
    # including the ones who never use it.
    homeManagerModules.default = import ./home-manager-module.nix self;
    homeModules.default = import ./home-manager-module.nix self;

    checks = lib.genAttrs systems (system: let
      pkgs = pkgsFor system;
      rex = self.packages.${system}.rex;
    in
      {
        # Check that the binary starts. On Linux this proves it can find every library it
        # links. On macOS it proves its signature is still valid.
        runs = pkgs.runCommand "rex-runs-check" {} ''
          ${rex}/bin/rex --help >/dev/null
          touch $out
        '';

        # Check that a terminfo reader can actually resolve the entry, under both of its
        # names and in both layouts. infocmp answers from the database alone, so it fails if
        # a file is missing, empty, or filed under the wrong name. Without this, a terminal
        # that claimed xterm-rex would only fail once someone ran a curses program in it.
        terminfo = pkgs.runCommand "rex-terminfo-check" {nativeBuildInputs = [pkgs.ncurses];} ''
          for name in x/xterm-rex 78/xterm-rex r/rex 72/rex; do
            test -s ${rex}/share/terminfo/$name
          done
          TERMINFO_DIRS=${rex}/share/terminfo infocmp -1 xterm-rex >/dev/null
          TERMINFO_DIRS=${rex}/share/terminfo infocmp -1 rex >/dev/null
          touch $out
        '';

        # The NixOS module includes the ssh guard from this path, so a package without it
        # would leave every generated ssh_config pointing at a file that is not there.
        ssh-guard = pkgs.runCommand "rex-ssh-guard-check" {} ''
          grep -q '^Match exec' ${rex}/share/rex/ssh_config.d/50-rex.conf
          touch $out
        '';
      }
      // lib.optionalAttrs pkgs.stdenv.hostPlatform.isLinux {
        # Check that the binary can find PAM. Without this, a missing PAM path would only show
        # up when someone first logs in through the login server. This check is only for
        # Linux, because Rex does not use PAM on macOS.
        pam-runpath = pkgs.runCommand "rex-pam-runpath-check" {nativeBuildInputs = [pkgs.patchelf];} ''
          patchelf --print-rpath ${rex}/bin/rex | tr : '\n' | grep -Fx ${lib.getLib pkgs.pam}/lib
          touch $out
        '';

        # Check that the binary's memory layout is intact. A Linux binary lists the regions of
        # memory the loader sets up when the program starts, each marked readable, writable,
        # or executable. readelf -lW prints each region as a LOAD line, and no two regions
        # may cover the same address.
        #
        # patchelf 0.19 breaks that rule when it sets the interpreter before the rpath
        # (NixOS/patchelf#674). The first region grows into the read-only region after it,
        # so data the loader must change at start ends up read-only and the program
        # crashes. The runs check would catch that by crashing too, but this check names
        # the cause. In a damaged binary, the second region starts at 0x10002fc, before
        # the first one ends at 0xfff000 + 0x1a6d0 = 0x10196d0:
        #
        #   Type  Offset   VirtAddr           PhysAddr           FileSiz  MemSiz   Flg
        #   LOAD  0x000000 0x0000000000fff000 0x0000000000fff000 0x01a6d0 0x01a6d0 RW
        #   LOAD  0x0012fc 0x00000000010002fc 0x00000000010002fc 0x1588338 0x1588338 R
        #
        # The loop prints the start and end address of each region, and awk fails as soon
        # as a region starts before an earlier one ends.
        load-segments =
          pkgs.runCommand "rex-load-segments-check" {
            nativeBuildInputs = [pkgs.binutils];
          } ''
            readelf -lW ${rex}/bin/rex | while read -r type _ vaddr _ _ memsz _; do
              if [ "$type" = LOAD ]; then echo "$((vaddr)) $((vaddr + memsz))"; fi
            done | sort -n | awk 'NR > 1 && $1 < end { exit 1 } $2 > end { end = $2 }'
            touch $out
          '';
      });
  };
}
